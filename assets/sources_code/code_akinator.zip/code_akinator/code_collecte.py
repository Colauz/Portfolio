import requests
import pandas as pd
import re

# Récupérer les informations sur les Pokémon et leurs évolutions à l'aide de l'API PokeAPI
url_pokeapi = "https://pokeapi.co/api/v2/pokemon/"
pokemon_details = {}

def get_pokemon_description(name):
    url = f"https://pokeapi.co/api/v2/pokemon-species/{name}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        pokemon_descriptions = data.get("flavor_text_entries")
        for description in pokemon_descriptions:
            if description.get("language").get("name") == "fr":
                return description.get("flavor_text")
    return None

def get_english_name(name):
    url = f"https://pokeapi.co/api/v2/pokemon/{name}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data["name"]
    return None

def get_pokemon_color(species_url):
    response_species = requests.get(species_url)
    if response_species.status_code == 200:
        species_data = response_species.json()
        pokemon_color_url = species_data['color']['url']
        response_color = requests.get(pokemon_color_url)
        if response_color.status_code == 200:
            color_data = response_color.json()
            pokemon_color = ""
            for name in color_data['names']:
                if name['language']['name'] == 'fr':
                    pokemon_color = name['name']
                    break
    return pokemon_color

for i in range(1, 840):
    response = requests.get(url_pokeapi + str(i))
    if response.status_code == 200:
        data = response.json()

        species_url = data['species']['url']
        response_species = requests.get(species_url)
        if response_species.status_code == 200:
            data_species = response_species.json()

            name = data_species['names'][4]['name']
            types = []
            for t in data['types']:
                type_url = t['type']['url']
                response_type = requests.get(type_url)
                if response_type.status_code == 200:
                    data_type = response_type.json()
                    types.append(data_type['names'][3]['name'])
            size = data['height'] / 10
            weight = data['weight'] / 10

            evolution_chain_url = data_species['evolution_chain']['url']
            response_evolution = requests.get(evolution_chain_url)
            if response_evolution.status_code == 200:
                data_evolution = response_evolution.json()

                evolutions = []
                evo_chain = data_evolution['chain']
                while evo_chain:
                    evo_species = evo_chain['species']
                    evo_species_url = evo_species['url']
                    evo_species_response = requests.get(evo_species_url)
                    if evo_species_response.status_code == 200:
                        evo_species_data = evo_species_response.json()
                        evo_name = evo_species_data['names'][4]['name']
                        if evo_name != name:
                            evolutions.append(evo_name)
                    evo_chain = evo_chain['evolves_to'][0] if evo_chain['evolves_to'] else None

                # Récupérer la génération du Pokémon
                generation_url = data_species['generation']['url']
                response_generation = requests.get(generation_url)
                if response_generation.status_code == 200:
                    data_generation = response_generation.json()
                    generation_name = data_generation['names'][3]['name']
                else:
                    generation_name = ""

                descriptions = []
                pokemon_name = get_english_name(str(i))
                description = get_pokemon_description(pokemon_name)
                pokemon_color = get_pokemon_color(species_url)


                if description:
                    # Remplacer les retours à la ligne par une chaîne vide
                    description = description.replace('\n', ' ')
                    descriptions.append(description)
                else:
                    descriptions.append(f"Impossible de trouver la description pour {pokemon_name.capitalize()}.")

                # Ajouter à pokemon_details uniquement si il y a des évolutions
                if len(evolutions) == 0:
                    evolutions = ["Aucune évolution"]
                pokemon_details[name] = {"Types": types, "Taille": size, "Poids": weight, "Évolutions": evolutions,
                                         "Génération": generation_name, "Descriptions": descriptions,
                                         "Couleur": pokemon_color}
                print(
                    f"{name}: Types: {', '.join(types)}, Taille: {size} m, Poids: {weight} kg, Évolutions: {', '.join(evolutions)}, Génération: {generation_name}, Description: {descriptions}, Color: {pokemon_color}")

data = []

for name, details in pokemon_details.items():
    if 'Évolutions' in details:
        evolutions = ", ".join(details['Évolutions'])
    else:
        evolutions = "Aucune évolution"
    data.append(
        {"Nom": name, "Types": ", ".join(details['Types']), "Taille": details['Taille'], "Poids": details['Poids'],
         "Évolutions": evolutions, "Generation": "".join(details["Génération"]),
         "Couleur": "".join(details["Couleur"]), "Description": " ".join(details['Descriptions'])})

pokemon_df = pd.DataFrame(data)

# Supprimer les lignes contenant des caractères japonais
japanese_regex = re.compile(r'[\u3040-\u30FF\u31F0-\u31FF\uFF65-\uFF9F]')
pokemon_df = pokemon_df[~(pokemon_df.astype(str).apply(lambda x: x.str.contains(japanese_regex)).any(axis=1))]

# Transformer la colonne "Poids" en catégorielle
pokemon_df['Poids'] = pd.qcut(pokemon_df['Poids'], q=3, labels=['léger', 'moyen', 'Lourd'])

# Transformer la colonne "Taille" en catégorielle
pokemon_df['Taille'] = pd.qcut(pokemon_df['Taille'], q=3, labels=['petit', 'moyen', 'Grand'])

# Affichez la DataFrame
print(pokemon_df)

# Exporter la DataFrame dans un fichier CSV
pokemon_df.to_csv("pokemon_data_api.csv", index=False, encoding='utf-8')