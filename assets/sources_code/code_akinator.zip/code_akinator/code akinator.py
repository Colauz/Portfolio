import csv
import math
from collections import Counter
import os

def load_data_from_csv(filename):
    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        data = [row for row in reader]
    return data

def calculate_entropy(attribute, data):
    counts = Counter(item[attribute] for item in data)
    probabilities = [count / len(data) for count in counts.values()]
    entropy = -sum(p * math.log2(p) for p in probabilities)
    return entropy

def get_answer(question_text):
    while True:
        answer = input(question_text).strip().lower()
        if answer in ['oui', 'non', 'je ne suis pas sûr']:
            return answer
        else:
            print("Réponse invalide. Veuillez répondre par 'oui', 'non' ou 'je ne suis pas sûr'.")




def ask_question(attribute, data, uncertain_attributes):
    possible_values = set(item[attribute] for item in data)
    if len(possible_values) == 1:
        return data, uncertain_attributes

    question_map = {
        'Types': "Est-ce que ton Pokémon est de type {value} ? (oui/non/je ne suis pas sûr) ",
        'Taille': "Est-ce que ton Pokémon est de taille {value} ? (oui/non/je ne suis pas sûr) ",
        'Poids': "Est-ce que ton Pokémon est de poids {value} ? (oui/non/je ne suis pas sûr) ",
        'Évolutions': "Est-ce que ton Pokémon évolue en {value} ? (oui/non/je ne suis pas sûr) ",
        'Generation': "Est-ce que ton Pokémon fait partie de la {value} ? (oui/non/je ne suis pas sûr) ",
        'Couleur': "Est-ce que ton Pokémon est de couleur {value} ? (oui/non/je ne suis pas sûr) ",
        'Description': "Est-ce que la description suivante correspond à ton Pokémon : {value} ? (oui/non/je ne suis pas sûr) "
    }

    new_data = data.copy()
    uncertain = False
    for value in possible_values:
        if value:
            question_text = question_map.get(attribute, '').format(value=value)
            answer = get_answer(question_text)
            if answer == 'oui':
                return [item for item in data if item[attribute] == value], uncertain_attributes
            elif answer == 'non':
                new_data = [item for item in new_data if item[attribute] != value]
            elif answer == 'je ne suis pas sûr':
                uncertain = True
                break

    if uncertain:
        uncertain_attributes.add(attribute)
        return data, uncertain_attributes
    return new_data, uncertain_attributes


# Charger la base de données Pokémon
try:
    database = load_data_from_csv('C:/Users/jamin/PycharmProjects/pythonProject14/pokemon_data_api.csv')
except FileNotFoundError:
    print("Le fichier 'pokemon_data_api.csv' est introuvable.")
    exit()

used_attributes = set()
uncertain_attributes = set()

while True:
    entropies = [(attr, calculate_entropy(attr, database)) for attr in database[0].keys() if
                 attr != 'Nom' and attr not in used_attributes]

    if uncertain_attributes:
        entropies = [entry for entry in entropies if entry[0] not in uncertain_attributes]

    if not entropies:
        break

    attribute, _ = min(entropies, key=lambda x: x[1])
    used_attributes.add(attribute)

    database, uncertain_attributes = ask_question(attribute, database, uncertain_attributes)

    # Si la base de données contient un seul élément, deviner le Pokémon
    if len(database) == 1:
        guess = database[0]['Nom']
        response = get_answer(f"Je pense que ton Pokémon est {guess}. Ai-je raison ? (oui/non) ")
        if response == 'oui':
            print("Génial, j'ai gagné !")
        else:
            print("Dommage, j'ai perdu.")


        # Proposer de recommencer une partie
        while True:
            restart = input("Voulez-vous recommencer une partie ? (oui/non) ").strip().lower()
            if restart == 'oui':
                used_attributes = set()
                uncertain_attributes = set()
                try:
                    database = load_data_from_csv('C:/Users/jamin/PycharmProjects/pythonProject14/pokemon_data_api.csv')
                except FileNotFoundError:
                    print("Le fichier 'pokemon_data_api.csv' est introuvable.")
                    exit()
                break
            elif restart == 'non':
                print("À bientôt !")
                exit()
            else:
                print("Réponse invalide. Veuillez répondre par 'oui' ou 'non'.")
                continue

    # Si la base de données est vide, signaler une erreur
    elif len(database) == 0:
        print("Je suis désolé, je n'ai pas pu deviner ton Pokémon.")
        break