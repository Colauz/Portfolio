﻿using Back_end.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_end.Entity
{
    [Table("user")]
    public class UserEntity
    {
        [Key]
        public string Mail { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string Salt { get; set; } = null!;
        public bool IsAdmin { get; set; }

        public List<SessionEntity> Sessions { get; set; } = new(); 
    }

}
