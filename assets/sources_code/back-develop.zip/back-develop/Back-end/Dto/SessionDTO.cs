﻿namespace Back_end.Dto
{
    public class SessionDTO
    {
        public bool IsAdmin { get; set; }  // Indique si l'utilisateur est un administrateur
        public string Token { get; set; } = null!;  // Token JWT ou autre identifiant de session
        public bool IsRevoked { get; set; }  // Indicateur si la session est révoquée ou non
    }
}
