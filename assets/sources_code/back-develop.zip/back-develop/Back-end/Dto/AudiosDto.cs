﻿namespace Back_end.DTO
{
    public class AudiosListDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Artist { get; set; } = "";
    }

    public class AudiosDto
    {
        public string Name { get; set; } = "";
        public string Artist { get; set; } = "";
        public double Duration { get; set; } = 0.0f;
    }
    public class AudiosSearchDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Artist { get; set; } = "";
        public double Duration { get; set; } = 0.0f;
        public int MatchScore { get; set; } = 0;
    }

    public class AudiosDtoWithFavorite
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Artist { get; set; } = "";
        public double Duration { get; set; } = 0.0f;
        public bool isFavorite { get; set; } = false;
    }
}
