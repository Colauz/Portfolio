﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_end.Models
{
    public class FingerPrint
    {
        public int Id { get; set; }          // Unique identifier for the fingerprint in database
        public double T1 { get; set; }      // Time position of the anchor point

        [Column(TypeName = "varchar(100)")]
        public string Hash { get; set; }
        public AudioPartition Partition { get; set; }
        public int PartitionId { get; set; }
    }

}
