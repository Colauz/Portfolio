﻿namespace Back_end.Models
{
    public class Spectograms
    {
        public double[,] Data { get; set; }
        public virtual List<FingerPrint> FingerPrint { get; set; } = [];


        // Constructor
        public Spectograms(int width, int height)
        {
            Data = new double[width, height];
        }
    }
}
