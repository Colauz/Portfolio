﻿using Back_end.Entity;

namespace Back_end.Models
{
    public class User
    {
        public required string Mail { get; set; }
        public required string PasswordHash { get; set; }
        public string salt { get; set; } = null!;
        public bool IsAdmin { get; internal set; }
    }

    public class UserRecentList
    {
        public int AudioId { get; set; }
        public virtual Audios Audio { get; set; }
        public string UserMail { get; set; }
        public virtual UserEntity User { get; set; }
        public bool isFavorite { get; set; } = false;
    }
}
