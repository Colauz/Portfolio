﻿using Back_end.Entity;
using Microsoft.EntityFrameworkCore;

namespace Back_end.Models
{
    public class ModelContext : DbContext
    {
        public ModelContext(DbContextOptions<ModelContext> options) : base(options)
        {
        }

        public virtual DbSet<Audios> Audios { get; set; }
        public virtual DbSet<AudioPartition> AudioPartition { get; set; }
        public virtual DbSet<FingerPrint> FingerPrint { get; set; }
        public virtual DbSet<UserEntity> Users { get; set; }
        public virtual DbSet<SessionEntity> Sessions { get; set; }
        public virtual DbSet<UserRecentList> RecentLists { get; set; }



        //public virtual DbSet<Spectograms> Spectograms { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Audios>(entity =>
            {
                entity.HasKey(a => a.Id);
                entity.Property(a => a.Name).IsRequired();

                entity.HasMany(a => a.Partitions)
                      .WithOne(p => p.Audio)
                      .HasForeignKey(p => p.AudioId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<AudioPartition>(entity =>
            {
                entity.HasKey(p => p.Id);

                entity.HasMany(p => p.FingerPrints)
                      .WithOne(f => f.Partition)
                      .HasForeignKey(f => f.PartitionId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<FingerPrint>(entity =>
            {
                entity.HasKey(f => f.Id);
                entity.Property(f => f.Hash).HasColumnType("varchar(100)").IsRequired();
            });


            modelBuilder.Entity<SessionEntity>(entity =>
            {
                entity.HasKey(s => s.Token);

                entity.HasOne(s => s.User)
                    .WithMany(u => u.Sessions)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<UserEntity>(entity =>
            {
                entity.HasKey(u => u.Mail);
            });

            modelBuilder.Entity<UserRecentList>(entity =>
            {
                entity.HasKey(ul => new { ul.UserMail, ul.AudioId });

                entity.HasOne(ul => ul.User)
                    .WithMany()
                    .HasForeignKey(ul => ul.UserMail)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(ul => ul.Audio)
                    .WithMany()
                    .HasForeignKey(ul => ul.AudioId)
                    .OnDelete(DeleteBehavior.Cascade);
            });
        }

    }
}
