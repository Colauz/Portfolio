﻿using System;

namespace Back_end.Models
{
    public class Session
    {
        public string Token { get; set; } = null!; // clé primaire
        public bool IsAdmin { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool IsRevoked { get; set; }
    }
}