﻿namespace Back_end.Models
{
    public class Audios
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Artist { get; set; } = "";
        public double Duration { get; set; } = 0.0f;

        public List<AudioPartition> Partitions { get; set; } = new List<AudioPartition>();
    }

    public class AudioPartition
    {
        public int Id { get; set; }

        public Audios Audio { get; set; }
        public int AudioId { get; set; }
        public List<FingerPrint> FingerPrints { get; set; } = new List<FingerPrint>();
    }
}
