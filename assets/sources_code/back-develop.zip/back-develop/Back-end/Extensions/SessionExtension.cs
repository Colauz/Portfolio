﻿using Back_end.Entity;
using Back_end.Models;
using Back_end.Dto;

namespace Back_end.Extensions
{
    public static class SessionExtension
    {
        public static Session ToModel(this SessionEntity session)
        {
            return new Session
            {
                Token = session.Token,
                IsAdmin = session.IsAdmin,
                CreatedAt = session.CreatedAt,
                ExpiresAt = session.ExpiresAt,
                IsRevoked = session.IsRevoked
            };
            
        }

        public static SessionDTO ToDTO(this Session session)
        {
            return new SessionDTO
            {
                Token = session.Token,
                IsAdmin = session.IsAdmin,
                IsRevoked = session.IsRevoked
            };
            
        }
    }
}
