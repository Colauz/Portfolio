﻿using Back_end.Dto;
using Back_end.Entity;
using Back_end.Models;

namespace Back_end.Extensions
{
    public static class UserExtension
    {

        public static UserEntity ToEntity(this User user)
        {
            return new UserEntity
            {

                Mail = user.Mail,
                PasswordHash = user.PasswordHash,
                Salt = user.salt,
                IsAdmin = user.IsAdmin
            };
        }

        public static User ToDomain(this UserEntity user)
        {
            return new User
            {
                Mail = user.Mail,
                PasswordHash = user.PasswordHash,
                salt = user.Salt,
                IsAdmin = user.IsAdmin
            };
        }

    }
}
