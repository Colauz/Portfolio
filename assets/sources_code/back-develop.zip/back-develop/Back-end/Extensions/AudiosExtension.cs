﻿using Back_end.DTO;
using Back_end.Models;

namespace Back_end.Extensions
{
    public static class AudiosExtension
    {
        public static AudiosDto ToDto(this Audios entity)
        {
            return new AudiosDto
            {
                Name = entity.Name,
                Artist = entity.Artist,
                Duration = entity.Duration
            };
        }

        public static AudiosListDto ToListDto(this Audios entity)
        {
            return new AudiosListDto
            {
                Id = entity.Id,
                Name = entity.Name,
                Artist = entity.Artist
            };
        }
    }
}
