﻿using Back_end.Models;

namespace Back_end.Services
{
    public class StubAuthService() : IAuthService
    {
        public Session? AuthenticateUser(string id, string password)
        {
            if (id == "admin" && password == "admin")
            {
                return new Session
                {
                    Token = "12345",
                    IsAdmin = true,
                    CreatedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.AddHours(1),
                    IsRevoked = false,
                };
            }
            else if (id == "user" && password == "user")
            {
                return new Session
                {
                    Token = "67890",
                    IsAdmin = false,
                    CreatedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.AddHours(1),
                    IsRevoked = false,
                };

            }
            else
            {
                return null;
            }
        }

        public Session? RegisterUser(string id, string password)
        {
            return null;
        }

        public bool Logout(string email)
        {
            return true;
        }

        public Session? IsLogged(string Token)
        {
            if (Token == "1")
            {

                return new Session
                {
                    Token = "1",
                    IsAdmin = false,
                    CreatedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.AddHours(1),
                    IsRevoked = false,
                };
            }
            else
            {
                return null;
            }
        }
    }
}
