using Back_end.Models;
namespace Back_end.Services
{
    public interface IAuthService
    {
        Session? AuthenticateUser(String id,String password);
        bool Logout(string token);
        Session? IsLogged(string token);
        Session? RegisterUser(String email, String password);

    }
}