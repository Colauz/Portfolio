﻿using Accord.Math;
using Back_end.Models;
using NAudio.Wave;
using System.Globalization;
using System.Numerics;
using System.Text.Json;

namespace Back_end.Services.Utils
{
    public class AudioConverter
    {
        public List<(int Frequency, double Time)> ExtractPeaksWithTime(byte[] pcmData, int sampleRate, int channels)
        {
            var peaksWithTime = new List<(int Frequency, double Time)>();

            int sampleSize = 4096; // samples per channel
            int stepSize = 4096;   // samples per channel
            int sampleBytes = 2 * channels; // bytes per frame (sample * channels)

            int windowByteSize = sampleSize * sampleBytes;
            int stepByteSize = stepSize * sampleBytes;

            for (int i = 0; i + windowByteSize < pcmData.Length; i += stepByteSize)
            {
                double[] window = new double[sampleSize];

                double timeInSeconds = i / (double)(sampleRate * sampleBytes / 2);
                // Or simpler: timeInSeconds = (i / sampleBytes) / sampleRate;

                for (int j = 0; j < sampleSize; j++)
                {
                    int sampleIndex = i + j * sampleBytes;

                    if (sampleIndex + 1 < pcmData.Length)
                    {
                        // Extract left channel only (channel 0)
                        short sample = (short)(pcmData[sampleIndex] | (pcmData[sampleIndex + 1] << 8));
                        window[j] = sample / 32768.0;
                    }
                }

                // Hanning window
                for (int j = 0; j < window.Length; j++)
                    window[j] *= (0.5 * (1 - Math.Cos(2 * Math.PI * j / (window.Length - 1))));

                Complex[] fftResult = window.Select(x => new Complex(x, 0)).ToArray();
                FourierTransform.FFT(fftResult, FourierTransform.Direction.Forward);

                double[] magnitudes = fftResult.Select(c => c.Magnitude).ToArray();

                int peakCount = 3;
                var topPeaks = magnitudes
                    .Skip(10)
                    .Select((value, index) => new { value, index = index + 10 })
                    .OrderByDescending(p => p.value)
                    .Take(peakCount)
                    .Select(p => p.index);

                foreach (var peak in topPeaks)
                {
                    peaksWithTime.Add((peak, timeInSeconds));
                }
            }

            return peaksWithTime;
        }


        public List<FingerPrint> GenerateFingerprints(List<(int Frequency, double Time)> peaks)
        {
            var fingerprints = new List<FingerPrint>();
            int fanOut = 5;

            for (int i = 0; i < peaks.Count; i++)
            {
                var anchor = peaks[i];

                for (int j = 1; j <= fanOut && (i + j) < peaks.Count; j++)
                {
                    var target = peaks[i + j];
                    double deltaT = target.Time - anchor.Time;

                    if (deltaT > 0 && deltaT < 5)
                    {
                        var roundedDeltaT = Math.Round(deltaT, 2);

                        var hashInput = $"{anchor.Frequency}|{target.Frequency}|{roundedDeltaT}";
                        var hash = ComputeHash(anchor.Frequency, target.Frequency, deltaT);


                        fingerprints.Add(new FingerPrint
                        {
                            T1 = anchor.Time,
                            Hash = hash
                        });
                    }
                }
            }

            return fingerprints;
        }
        private string ComputeHash(int f1, int f2, double dt)
        {
            var roundedDt = Math.Round(dt, 2);
            var input = $"{f1}|{f2}|{roundedDt.ToString(CultureInfo.InvariantCulture)}";
            using (var sha1 = System.Security.Cryptography.SHA1.Create())
            {
                var bytes = System.Text.Encoding.UTF8.GetBytes(input);
                var hashBytes = sha1.ComputeHash(bytes);
                return Convert.ToBase64String(hashBytes);
            }
        }
    }

}
