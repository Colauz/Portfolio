﻿using Back_end.Models;
using System.Text.Json;

namespace Back_end.Services.Utils
{
    public class AuthConverter
    {

        public static Session? JSONToSession(string json)
        {
            // Convert JSON to Spectograms object

            // Exemple de désérialisation JSON -- TODO
            return JsonSerializer.Deserialize<Session>(json);
        }

        public static string SessionToJSON(Session session)
        {
            // Convert Spectograms object to JSON
            // Exemple de sérialisation JSON -- TODO
            return JsonSerializer.Serialize(session);
        }
    }
}
