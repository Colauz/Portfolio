﻿using Back_end.Models;
using Back_end.Entity;
using Back_end.Services.Utils;
using Back_end.Extensions;

namespace Back_end.Services
{
    public class DBAuthService(ModelContext context) : IAuthService
    {
        public Session? AuthenticateUser(string email, string password)
        {

            var user = context.Users.Find(email);
            
            
            if (user != null )
            {
               
                if (CryptoSecurity.VerifyPassword(password, user.PasswordHash, user.Salt)){
                    SessionEntity session = new SessionEntity
                    {
                        Token = Guid.NewGuid().ToString(),
                        User = user,
                        IsAdmin = user.IsAdmin,
                        CreatedAt = DateTime.UtcNow,
                        ExpiresAt = DateTime.UtcNow.AddHours(1)
                    };
                context.Sessions.Add(session);
                context.SaveChanges();

                return session.ToModel();
                }
                else
                {
                    return null;
                } 
            }
            else
            {
                return null;
            }
        }

        public Session? RegisterUser(string mail, string password)
        {
            var user = context.Users.Find(mail);
            if (user == null)
            {
                var (hash, salt) = CryptoSecurity.HashPassword(password);

                user = new UserEntity
                {
                    Mail = mail,
                    PasswordHash = hash, // Correctly assigning the hash
                    Salt = salt,         
                    IsAdmin = false
                };
                context.Users.Add(user);

                SessionEntity session = new SessionEntity
                {
                    Token = Guid.NewGuid().ToString(),
                    User = user,
                    IsAdmin = user.IsAdmin,
                    CreatedAt = DateTime.UtcNow,
                    ExpiresAt = DateTime.UtcNow.AddHours(1)
                };
                context.Add(session);

                user.Sessions.Add(session);
                context.SaveChanges();

                return session.ToModel();
            }
            else
            {
                return null;
            }
        }

        public bool Logout(string token)
        {
            var session = context.Sessions.Find(token);
            if (session != null && !session.IsRevoked)
            {
                session.IsRevoked = true;
                context.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public Session? IsLogged(string token)
        {
            var session = context.Sessions.Find(token);
            if (session != null && !session.IsRevoked && session.ExpiresAt > DateTime.UtcNow)
            {
                return session.ToModel();
            }
            else
            {
                return null;
            }
        }
    }
}
