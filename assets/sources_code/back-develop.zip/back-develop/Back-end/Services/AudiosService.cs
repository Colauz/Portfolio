﻿using Back_end.DTO;
using Back_end.Extensions;
using Back_end.Models;
using Back_end.Services.Utils;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NAudio.Wave;
using System;
using System.Linq;

namespace Back_end.Services
{
    public class AudiosService(ModelContext context, AudioConverter audioConverter)
    {

        public List<AudiosListDto> GetAllAudios()
        {
            return context.Audios.Select(a => a.ToListDto()).ToList();
        }


        public async Task<List<AudiosDtoWithFavorite>> GetRecentOfUserAsync(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new ArgumentException("Token cannot be null or empty.", nameof(token));
            }

            var session = context.Sessions
                .Include(s => s.User)
                .FirstOrDefault(s => s.Token == token);

            if (session == null)
            {
                throw new Exception("Session not found.");
            }

            var recentList = await context.RecentLists
                .Where(r => r.UserMail == session.User.Mail)
                .ToListAsync();

            if (recentList == null || !recentList.Any())
            {
                return new List<AudiosDtoWithFavorite>();
            }

            var audios = new List<AudiosDtoWithFavorite>();

            foreach (var recent in recentList)
            {
                var audio = await context.Audios
                    .Where(a => a.Id == recent.AudioId)
                    .Select(a => new AudiosDtoWithFavorite
                    {
                        Id = a.Id,
                        Name = a.Name,
                        Artist = a.Artist,
                        Duration = a.Duration,
                        isFavorite = recent.isFavorite
                    })
                    .FirstOrDefaultAsync();
                if (audio != null)
                {
                    audios.Add(audio);
                }
            }

            return audios;
        }


        public async Task<List<FingerPrint>> GetFingerPrints(IFormFile file)
        {

            using var memoryStream = new MemoryStream();
            await file.CopyToAsync(memoryStream);
            memoryStream.Position = 0;

            int sampleRate;
            int channels;

            using (var reader = new WaveFileReader(memoryStream))
            {
                sampleRate = reader.WaveFormat.SampleRate;
                channels = reader.WaveFormat.Channels;

                using var pcmStream = WaveFormatConversionStream.CreatePcmStream(reader);
                using var rawStream = new MemoryStream();
                pcmStream.CopyTo(rawStream);
                byte[] pcmData = rawStream.ToArray();

                var peaks = audioConverter.ExtractPeaksWithTime(pcmData, sampleRate, channels);

                var fingerprints = audioConverter.GenerateFingerprints(peaks);

                return fingerprints ?? new List<FingerPrint>();
            }

        }

        public async Task<ActionResult> CreateAudio(AudiosDto audio)
        {
            var newAudio = new Audios
            {
                Name = audio.Name,
                Artist = audio.Artist,
                Duration = audio.Duration
            };
            context.Audios.Add(newAudio);
            await context.SaveChangesAsync();
            return new CreatedAtActionResult(nameof(GetAllAudios), "Audios", new { id = newAudio.Id }, newAudio.ToListDto());
        }

        public async Task<ActionResult> SaveAudioPartitionFingerprintAsync(IFormFile file, int audioId)
        {
            var fingerprints = await GetFingerPrints(file);

            var newPartition = new AudioPartition
            {
                FingerPrints = fingerprints
            };

            var audio = await context.Audios.SingleOrDefaultAsync(a => a.Id == audioId);

            if (audio == null)
                return new NotFoundObjectResult("Audio not found.");

            audio.Partitions.Add(newPartition);

            await context.SaveChangesAsync();

            return new StatusCodeResult(StatusCodes.Status201Created);
        }

        public async Task<AudiosSearchDto> SearchAudioWithFingerprintsAsync(IFormFile file)
        {
            var queryFingerprints = await GetFingerPrints(file);

            if (queryFingerprints == null || !queryFingerprints.Any())
                throw new Exception("No fingerprints");

            var queryHashes = queryFingerprints.Select(fp => fp.Hash).ToHashSet();

            // Fetch all matching fingerprints from DB
            var dbMatches = await context.FingerPrint
                .Where(fp => queryHashes.Contains(fp.Hash))
                .ToListAsync();

            if (!dbMatches.Any())
            {
                var queryHashesStr = string.Join(", ", queryHashes.Take(10)); // limit to first 10 for brevity
                var dbMatchesCount = dbMatches.Count;

                return new AudiosSearchDto
                {
                    Id = -1,
                    Name = "No match found. QueryHashes: " + queryHashesStr,
                    Artist = "DB Matches count: " + dbMatchesCount,
                    MatchScore = 0,
                };
            }

            // PartitionId -> Offset -> Count
            var offsetMap = new Dictionary<int, Dictionary<int, int>>();

            // Handle multiple query fingerprints with same hash
            foreach (var dbFp in dbMatches)
            {
                var matchingQueryFps = queryFingerprints.Where(q => q.Hash == dbFp.Hash);

                foreach (var queryFp in matchingQueryFps)
                {
                    int offset = (int)Math.Round(dbFp.T1 - queryFp.T1);

                    if (!offsetMap.ContainsKey(dbFp.PartitionId))
                        offsetMap[dbFp.PartitionId] = new Dictionary<int, int>();

                    if (!offsetMap[dbFp.PartitionId].ContainsKey(offset))
                        offsetMap[dbFp.PartitionId][offset] = 0;

                    offsetMap[dbFp.PartitionId][offset]++;
                }
            }

            // Find best match: Partition with most consistent time offset
            var bestMatchPartition = offsetMap
                .Select(entry => new
                {
                    PartitionId = entry.Key,
                    MaxCount = entry.Value.Values.Max()
                })
                .OrderByDescending(e => e.MaxCount)
                .FirstOrDefault();

            // Use a dynamic threshold based on input size
            int dynamicThreshold = Math.Max(10, queryFingerprints.Count / 15); // Modify this value as needed

            if (bestMatchPartition == null || bestMatchPartition.MaxCount < dynamicThreshold)
            {
                return new AudiosSearchDto
                {
                    Id = -1,
                    Name =  "No match found.",
                    Artist = "Please try again.",
                    MatchScore = bestMatchPartition.MaxCount,
                };
            }

            // Get audio and partition info
            var partition = await context.AudioPartition.FindAsync(bestMatchPartition.PartitionId);
            if (partition == null)
                throw new Exception("Partition not found.");

            var audio = await context.Audios.FindAsync(partition.AudioId);
            if (audio == null)
                throw new Exception("Audio not found.");

            return new AudiosSearchDto
            {
                Id = audio.Id,
                Name = audio.Name,
                Artist = audio.Artist,
                Duration = audio.Duration,
                MatchScore = bestMatchPartition.MaxCount,
            };
        }

        public async Task AddAudioToUserRecents(int id, string userToken)
        {
            var session = context.Sessions
                .Include(s => s.User)
                .FirstOrDefault(s => s.Token == userToken);

            if (session?.User == null)
            {
                return;
            }

            var potentialRecent = await context.RecentLists
                .CountAsync(r => r.AudioId == id && r.UserMail == session.User.Mail);

            if (potentialRecent != 0)
            {
                return;
            }


            var input = new UserRecentList
            {
                AudioId = id,
                UserMail = session.User.Mail
            };

            context.RecentLists.Add(input);
            await context.SaveChangesAsync();
        }

        public async Task ChangeAudioToUserFavorites(int id, string userToken, bool status = false)
        {
            var session = await context.Sessions.Include(s => s.User).SingleOrDefaultAsync(s => s.Token == userToken);

            if (session?.User == null)
            {
                return;
            }

            var recent = await context.RecentLists.SingleOrDefaultAsync(r => r.AudioId == id && r.UserMail == session.User.Mail);

            recent.isFavorite = status;

            await context.SaveChangesAsync();
        }

        public async Task DeleteAudio(int id, string userToken)
        {

            if (string.IsNullOrEmpty(userToken))
            {
                throw new ArgumentException("User token cannot be null or empty.", nameof(userToken));
            }

            var session = context.Sessions
                .Include(s => s.User)
                .FirstOrDefault(s => s.Token == userToken);

            if (session == null)
            {
                throw new Exception("Session not found.");
            }

            if(session.User.IsAdmin == false)
            {
                throw new Exception("User is not admin.");
            }

            var audio = await context.Audios
                .SingleOrDefaultAsync(a => a.Id == id);

            context.Audios.Remove(audio);

            await context.SaveChangesAsync();
        }

        public async Task RemoveAudioFromUserRecents(int id, string userToken)
        {
            if (string.IsNullOrEmpty(userToken))
            {
                throw new ArgumentException("User token cannot be null or empty.", nameof(userToken));
            }

            var session = await context.Sessions
                .Include(s => s.User)
                .SingleOrDefaultAsync(s => s.Token == userToken);

            if (session == null)
            {
                throw new Exception("Session not found.");
            }

            var recent = await context.RecentLists
                .SingleOrDefaultAsync(r => r.AudioId == id && r.UserMail == session.User.Mail);

            if (recent != null)
            {
                context.RecentLists.Remove(recent);
                await context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Recent audio not found.");
            }
        }

    }
}
