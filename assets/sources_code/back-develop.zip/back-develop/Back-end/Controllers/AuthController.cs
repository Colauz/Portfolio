

using Back_end.Extensions;
using Back_end.Services;

using Microsoft.AspNetCore.Mvc;

namespace Back_end.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController(IAuthService service) : ControllerBase
    {

        [HttpPost("login")]
        public IActionResult Login(string Email, string Password)
        {
            var session = service.AuthenticateUser(Email, Password);
            if (session == null)
            {
                return Unauthorized();
            }
            return Ok(session.ToDTO());
        }

        [HttpPost("register")]
        public IActionResult Register(string Email, string Password)
        {
            var session = service.RegisterUser(Email, Password);
            if (session == null)
            {
                return BadRequest();
            }
            return Ok(session.ToDTO());
        }

        [HttpPost("logout")]
        public IActionResult Logout(string Token)
        {
            if (service.Logout(Token))
            {
                return Ok();
            }
            return BadRequest();
        }

        [HttpGet("isLogged")]
        public IActionResult IsLogged(string Token)
        {
            var session = service.IsLogged(Token);
            if (session == null)
            {
                return Unauthorized();
            }
            return Ok(session.ToDTO());
        }




    }
}