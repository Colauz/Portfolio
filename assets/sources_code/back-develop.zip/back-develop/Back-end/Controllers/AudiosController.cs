﻿using Back_end.Services;
using Microsoft.AspNetCore.Mvc;
using Back_end.Services.Utils;
using Back_end.DTO;
using NAudio.Wave;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Back_end.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AudiosController(AudiosService service, AudioConverter audioConverter) : ControllerBase
    {

        [HttpGet]
        public IActionResult GetAllAudios()
        {
            var results = service.GetAllAudios();
            return Ok(results);
        }


        [HttpGet("recents")]
        public async Task<IActionResult> GetRecents(string userToken)
        {
            var results = await service.GetRecentOfUserAsync(userToken);
            return Ok(results);
        }

        [HttpPost]
        public async Task<IActionResult> CreateAudio(AudiosDto body)
        {
            var result = await service.CreateAudio(body);

            return result;
        }

        [HttpPost("upload/{id}")]
        public async Task<IActionResult> SaveFingerPrints(IFormFile file, int id)
        {
            if (file == null || file.Length == 0)
                return BadRequest("Fichier manquant.");

            var result = await service.SaveAudioPartitionFingerprintAsync(file, id);

            return result;
        }

        [HttpPost("search")]
        public async Task<IActionResult> LookForFingerPrints(IFormFile file, string? userToken)
        {
            if (file == null || file.Length == 0)
                return BadRequest("Fichier manquant.");

            var result = await service.SearchAudioWithFingerprintsAsync(file);

            if(userToken != null && result.Id != null)
            {
                await service.AddAudioToUserRecents(result.Id, userToken);
            }

            return Ok(result);
        }


        [HttpPost("favorite/{id}")]
        public async Task<IActionResult> ChangeAudioToUserFavorites(int id, string userToken, bool status = false)
        {
            if (userToken != null)
            {
                await service.ChangeAudioToUserFavorites(id, userToken, status);
            }

            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAudio(int id, string userToken)
        {
            await service.DeleteAudio(id, userToken);
            return Ok();
        }

        [HttpDelete("recent/{id}")]
        public async Task<IActionResult> RemoveAudioFromHistory(int id, string userToken)
        {
            if (userToken != null)
            {
                await service.RemoveAudioFromUserRecents(id, userToken);
            }
            return Ok();
        }
    }
}

