const axios = require('axios');
const mysql = require('mysql2/promise');

const connectionConfig = {
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'holacine'
};

const API_KEY = '8a9c16ae1fb7abf28b01f91531bb3bc5';
const BASE_URL = `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&language=fr-FR&page=`;
const MOVIE_DETAILS_URL = `https://api.themoviedb.org/3/movie/`;

const FETCH_MOVIES_CONCURRENCY = 10;

async function fetchAndInsertGenres(movieId, connection, genres) {
  try {
    for (const genre of genres) {
      await connection.execute(
        `INSERT IGNORE INTO genres (id, name) VALUES (?, ?)`,
        [genre.id, genre.name]
      );
      await connection.execute(
        `INSERT IGNORE INTO movie_genres (movie_id, genre_id) VALUES (?, ?)`,
        [movieId, genre.id]
      );
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération des genres pour le film ${movieId}: ${error}`);
    throw error;
  }
}

async function fetchAndInsertActors(movieId, connection, actors) {
  try {
    for (const actor of actors) {
      await connection.execute(
        `INSERT IGNORE INTO actors (id, name) VALUES (?, ?)`,
        [actor.id, actor.name]
      );
      await connection.execute(
        `INSERT IGNORE INTO movie_actor (movie_id, actor_id) VALUES (?, ?)`,
        [movieId, actor.id]
      );
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération des acteurs pour le film ${movieId}: ${error}`);
    throw error;
  }
}

async function fetchAndInsertDirectors(movieId, connection, directors) {
  try {
    for (const director of directors) {
      await connection.execute(
        `INSERT IGNORE INTO directors (id, name) VALUES (?, ?)`,
        [director.id, director.name]
      );
      await connection.execute(
        `INSERT IGNORE INTO director_movie (director_id, movie_id) VALUES (?, ?)`,
        [director.id, movieId]
      );
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération des réalisateurs pour le film ${movieId}: ${error}`);
    throw error;
  }
}

async function fetchAndStoreTrailerUrl(movieId, connection, videos) {
  try {
    let trailers = videos.filter(video => video.type === "Trailer" && video.site === "YouTube");
    let trailerUrl = trailers.length > 0 ? `https://www.youtube.com/watch?v=${trailers[0].key}` : null;

    if (!trailerUrl) {
      const videosResponse = await axios.get(`${MOVIE_DETAILS_URL}${movieId}/videos?api_key=${API_KEY}&language=en-US`);
      trailers = videosResponse.data.results.filter(video => video.type === "Trailer" && video.site === "YouTube");
      trailerUrl = trailers.length > 0 ? `https://www.youtube.com/watch?v=${trailers[0].key}` : null;
    }

    if (trailerUrl) {
      await connection.execute(
        `UPDATE movies SET trailer_url = ? WHERE movie_id = ?`,
        [trailerUrl, movieId]
      );
    } else {
      console.log(`Bande-annonce vide ou manquante pour le film ${movieId}, pas de mise à jour de ce champ.`);
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération de la bande annonce pour le film ${movieId}: ${error}`);
  }
}

async function fetchAndStoreMovieResume(movieId, connection, resume) {
  try {
    if (resume && resume.trim().length > 0) {
      await connection.execute(
        `UPDATE movies SET resume = ? WHERE movie_id = ?`,
        [resume, movieId]
      );
    } else {
      console.log(`Résumé vide ou manquant pour le film ${movieId}, pas de mise à jour de ce champ.`);
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération du résumé pour le film ${movieId}: ${error}`);
  }
}

async function fetchAndInsertDirectorGenres(directorId, movieGenres, connection) {
  try {
    for (const genre of movieGenres) {
      await connection.execute(
        `INSERT IGNORE INTO director_genre (director_id, genre_id) VALUES (?, ?)`,
        [directorId, genre.id]
      );
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération des genres pour le réalisateur ${directorId}: ${error}`);
    throw error;
  }
}

async function fetchAndInsertActorGenres(actorId, movieGenres, connection) {
  try {
    for (const genre of movieGenres) {
      await connection.execute(
        `INSERT IGNORE INTO actor_genre (actor_id, genre_id) VALUES (?, ?)`,
        [actorId, genre.id]
      );
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération des genres pour l'acteur ${actorId}: ${error}`);
    throw error;
  }
}


async function fetchAndStoreReleaseDate(movieId, connection, releaseDate) {
  try {
    if (releaseDate) {
      await connection.execute(
        `UPDATE movies SET sortie_date = ? WHERE movie_id = ?`,
        [releaseDate, movieId]
      );
    } else {
      console.log(`Date de sortie vide ou manquante pour le film ${movieId}, pas de mise à jour de ce champ.`);
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération de la date de sortie pour le film ${movieId}: ${error}`);
  }
}

async function fetchAndStorePopularityScore(movieId, connection, popularityScore) {
  try {
    if (popularityScore !== null) {
      await connection.execute(
        `UPDATE movies SET popularity_score = ? WHERE movie_id = ?`,
        [popularityScore, movieId]
      );
    } else {
      console.log(`Score de popularité vide ou manquant pour le film ${movieId}, pas de mise à jour de ce champ.`);
    }
  } catch (error) {
    console.error(`Erreur lors de la récupération du score de popularité pour le film ${movieId}: ${error}`);
  }
}

async function updateNumberOfEntries(movieId, connection, numberOfEntries) {
  try {
    if (numberOfEntries !== null && numberOfEntries >= 0) {
      await connection.execute(
        `UPDATE movies SET box_office = ? WHERE movie_id = ?`,
        [numberOfEntries, movieId]
      );
    } else {
      console.log(`Nombre d'entrées invalide ou manquant pour le film ${movieId}, pas de mise à jour de ce champ.`);
    }
  } catch (error) {
    console.error(`Erreur lors de la mise à jour du nombre d'entrées pour le film ${movieId}: ${error}`);
  }
}


async function fetchAndStoreNumberOfRating(movieId, connection) {
  try {
    const detailsResponse = await axios.get(`${MOVIE_DETAILS_URL}${movieId}?api_key=${API_KEY}&language=fr-FR`);
    const numberOfRatings = detailsResponse.data.vote_count || 0;

    console.log(`Number of ratings for movie ${movieId}:`, numberOfRatings);

    await connection.execute(
      `UPDATE movies SET number_of_ratings = ? WHERE movie_id = ?`,
      [numberOfRatings, movieId]
    );

    console.log(`Updated number of ratings for movie ${movieId} in the database.`);
  } catch (error) {
    console.error(`Erreur lors de la récupération du nombre de votes pour le film ${movieId}: ${error}`);
  }
}

  async function fetchAndStoreMovieData(movieId, connection) {
    try {
      const response = await axios.get(`${MOVIE_DETAILS_URL}${movieId}?api_key=${API_KEY}&language=fr-FR&append_to_response=credits,videos`);
      const { data } = response;
  
      const duration = data.runtime || 0;
      const director = data.credits.crew.find(crewMember => crewMember.job === 'Director')?.name || 'Inconnu';
      const actors = data.credits.cast.slice(0, 3).map(actor => ({ id: actor.id, name: actor.name }));
      const directors = data.credits.crew.filter(crewMember => crewMember.job === 'Director').map(director => ({ id: director.id, name: director.name }));
  
      await fetchAndInsertGenres(movieId, connection, data.genres);
      await fetchAndStoreTrailerUrl(movieId, connection, data.videos.results);
      await fetchAndStoreMovieResume(movieId, connection, data.overview);
      await fetchAndStoreReleaseDate(movieId, connection, data.release_date);
      await fetchAndStorePopularityScore(movieId, connection, data.popularity);
      await fetchAndInsertActors(movieId, connection, actors);
      await fetchAndInsertDirectors(movieId, connection, directors);
      await fetchAndInsertActors(movieId, connection, actors);
      await fetchAndInsertDirectors(movieId, connection, directors);
      fetchAndStoreNumberOfRating(movieId, connection, data.vote_count);
      const revenue = data.revenue || 0;
      await updateNumberOfEntries(movieId, connection, revenue);      
    
      for (const actor of actors) {
        await fetchAndInsertActorGenres(actor.id, data.genres, connection);
      }
      for (const director of directors) {
        await fetchAndInsertDirectorGenres(director.id, data.genres, connection);
      }
  
      await connection.execute(
        `UPDATE movies SET duration = ?, director = ? WHERE movie_id = ?`,
        [duration, director, movieId]
      );
    } catch (error) {
      console.error(`Erreur lors de la récupération des données pour le film ${movieId}: ${error}`);
    }
  }
  
  const importMovies = async () => {
    const connection = await mysql.createConnection(connectionConfig);
    console.log('Connecté à la base de données MySQL');
  
    try {
      await connection.beginTransaction();
      let currentPage = 1;
      const totalPages = 200;
  
      while (currentPage <= totalPages) {
        const response = await axios.get(`${BASE_URL}${currentPage}`);
        const movies = response.data.results;
        const moviePromises = movies.map(async (movie) => {
          if (!movie.poster_path || !movie.id || movie.vote_average == null) {
            console.log(`Film ignoré (données manquantes): ${movie.title}`);
            return;
          }
          try {
            await processMovie(movie, connection);
          } catch (error) {
            console.error(`Erreur lors du traitement du film ${movie.id}: ${error}`);
          }
        });
  
        await Promise.all(moviePromises);
        currentPage++;
      }
  
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      console.error('Erreur globale, transaction annulée:', error);
    } finally {
      await connection.end();
      console.log('Déconnecté de la base de données.');
    }
  };
  
  const processMovie = async (movie, connection) => {
    const { title, poster_path, id: movie_id, vote_average: rating } = movie;
    const [rows] = await connection.execute('SELECT movie_id FROM movies WHERE movie_id = ?', [movie_id]);
  
    if (rows.length === 0) {
      console.log(`Insertion du film : ${title}`);
      await connection.execute(
        `INSERT INTO movies (title, poster_path, movie_id, rating) VALUES (?, ?, ?, ?)`,
        [title, poster_path, movie_id, rating]
      );
    } else {
      console.log(`Mise à jour du film : ${title}`);
      await connection.execute(
        `UPDATE movies SET title = ?, poster_path = ?, rating = ? WHERE movie_id = ?`,
        [title, poster_path, rating, movie_id]
      );
    }
  
    const moviePromises = [];
  
    moviePromises.push(fetchAndStoreMovieData(movie_id, connection));
  
    if (moviePromises.length === FETCH_MOVIES_CONCURRENCY) {
      await Promise.all(moviePromises);
      moviePromises.length = 0;
    }
  
    if (moviePromises.length > 0) {
      await Promise.all(moviePromises);
    }
  };
  
  importMovies();