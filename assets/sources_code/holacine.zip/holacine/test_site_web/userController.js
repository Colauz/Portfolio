const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const connection = require('./db');
const { spawn } = require('child_process');
const express = require('express');

async function executePythonScript(movieId) {
  return new Promise((resolve, reject) => {
    const pythonProcess = spawn('python', ['reco.py', movieId]);

    let pythonOutput = '';

    pythonProcess.stdout.on('data', (data) => {
      pythonOutput += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error(`Erreur du processus enfant : ${data}`);
    });

    pythonProcess.on('close', (code) => {
      if (code === 0) {
        resolve(pythonOutput);
      } else {
        reject(new Error(`Le script Python s'est terminé avec le code de sortie : ${code}`));
      }
    });
  });
}

async function inscrireUtilisateur(req, res) {
  const { nom, prenom, email, motdepasse, pseudo, selectedMovieIds } = req.body;

  const checkUserQuery = 'SELECT email, pseudo FROM users WHERE email = ? OR pseudo = ?';
  connection.query(checkUserQuery, [email, pseudo], async (err, results) => {
    if (err) {
      console.error('Erreur lors de la vérification de l\'utilisateur:', err);
      return res.status(500).json({ error: 'Erreur serveur lors de la vérification de l\'utilisateur' });
    }

    const isEmailTaken = results.some(result => result.email === email);
    const isPseudoTaken = results.some(result => result.pseudo === pseudo);
    if (isEmailTaken || isPseudoTaken) {
      return res.status(400).json({
        message: `Cet ${isEmailTaken ? 'email' : 'pseudo'} est déjà utilisé`
      });
    }

    const hashedPassword = await bcrypt.hash(motdepasse, 10);

    const dateRegister = new Date();
    const formattedDate = dateRegister.toISOString().split('T')[0];

    const queryString = 'INSERT INTO users (nom, prenom, email, password, pseudo, statut, date_register) VALUES (?, ?, ?, ?, ?, "user", ?)';

    connection.query(queryString, [nom, prenom, email, hashedPassword, pseudo, formattedDate], async (err, results) => {
      if (err) {
        console.error('Erreur lors de l\'insertion dans la base de données:', err);
        return res.status(500).json({ error: 'Erreur lors de l\'inscription' });
      }

      const insertedUserId = results.insertId;

      const ratingsQueryString = 'INSERT INTO user_movie_ratings (user_id, movie_id, rating) VALUES ?';
      const ratingsValues = selectedMovieIds.map(movieId => [insertedUserId, movieId, 1]);

      connection.query(ratingsQueryString, [ratingsValues], async (err, ratingsResults) => {
        if (err) {
          console.error('Erreur lors de l\'insertion des données dans la table user_movie_ratings:', err);
          return res.status(500).json({ error: 'Erreur lors de l\'enregistrement des films préférés' });
        }

        console.log('Films préférés enregistrés avec succès');

        res.status(200).json({ message: 'Inscription réussie', redirectTo: '/' });

        await executePythonScript(insertedUserId);
      });
    });
  });
}

async function gererConnexion(req, res) {
  const { email, password } = req.body;

  const queryString = 'SELECT * FROM users WHERE email = ?';
  connection.query(queryString, [email], async (err, results) => {
    if (err) {
      console.error('Erreur lors de la recherche de l\'utilisateur :', err);
      return res.status(500).json({ error: 'Erreur serveur' });
    }
    if (results.length === 0) {
      return res.status(401).json({ error: 'Identifiants incorrects' });
    }
    const utilisateur = results[0];

    const match = await bcrypt.compare(password, utilisateur.password);
    if (!match) {
      return res.status(401).json({ error: 'Identifiants incorrects' });
    }

    req.session.userId = utilisateur.id;
    res.status(200).json({ message: 'Connexion réussie', estConnecte: true, redirectTo: '/' });
  });
}

module.exports = { inscrireUtilisateur, gererConnexion };

