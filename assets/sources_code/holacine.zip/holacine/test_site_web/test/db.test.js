const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'mysql',
  port: 3306,
  user: 'root',
  password: 'root',
  database: 'holacine'
});

connection.connect(err => {
  if (err) {
    console.error('Erreur de connexion à la base de données : ' + err.stack);
    process.exit(1); 
  } else {
    console.log('Connecté à la base de données avec succès.');
    connection.end(() => {
      console.log('Connexion terminée.');
      process.exit(0);
    });
  }
});
