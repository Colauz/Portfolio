# la bdd doit s'appeller et utiliser mysql pour mon site :

holacine

# Commande si besoin pour vider les tables :

TRUNCATE TABLE users; TRUNCATE TABLE movie_genres; TRUNCATE TABLE
user_movie_ratings; TRUNCATE TABLE user_movie_recommendations; TRUNCATE TABLE
genres; TRUNCATE TABLE actors; TRUNCATE TABLE directors; TRUNCATE TABLE
actor_genre; TRUNCATE TABLE movie_actor; TRUNCATE TABLE director_genre; TRUNCATE
TABLE director_movie; TRUNCATE TABLE movies;

# Pour vider les tables il vous faut désactiver les clés étrangères

SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;

# Création des tables :

CREATE TABLE IF NOT EXISTS users ( id INT PRIMARY KEY AUTO_INCREMENT, nom
VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, pseudo VARCHAR(255) NOT
NULL UNIQUE, email VARCHAR(255) NOT NULL UNIQUE, bio TEXT, password VARCHAR(255)
NOT NULL, preference VARCHAR(255), statut ENUM('user', 'admin') NOT NULL DEFAULT
'user', photo_profil VARCHAR(255), date_register DATETIME NOT NULL DEFAULT
CURRENT_TIMESTAMP );

CREATE TABLE movie_genres ( movie_id INT, genre_id INT, FOREIGN KEY (movie_id)
REFERENCES movies(movie_id), FOREIGN KEY (genre_id) REFERENCES genres(id),
PRIMARY KEY (movie_id, genre_id) );

CREATE TABLE user_movie_ratings ( user_id INT NOT NULL, movie_id INT NOT NULL,
rating INT, PRIMARY KEY (user_id, movie_id) );

CREATE TABLE user_movie_recommendations ( user_id INT NOT NULL, movie_id INT NOT
NULL, PRIMARY KEY (user_id, movie_id) );

CREATE TABLE genres ( id INT PRIMARY KEY, name VARCHAR(255) NOT NULL );

CREATE TABLE IF NOT EXISTS actors ( id INT PRIMARY KEY, name VARCHAR(255) NOT
NULL );

CREATE TABLE IF NOT EXISTS directors ( id INT PRIMARY KEY, name VARCHAR(255) NOT
NULL );

CREATE TABLE IF NOT EXISTS actor_genre ( actor_id INT, genre_id INT, PRIMARY KEY
(actor_id, genre_id), FOREIGN KEY (actor_id) REFERENCES actors(id), FOREIGN KEY
(genre_id) REFERENCES genres(id) );

CREATE TABLE IF NOT EXISTS movie_actor ( movie_id INT, actor_id INT, PRIMARY KEY
(movie_id, actor_id), FOREIGN KEY (movie_id) REFERENCES movies(movie_id),
FOREIGN KEY (actor_id) REFERENCES actors(id) );

CREATE TABLE IF NOT EXISTS director_genre ( director_id INT, genre_id INT,
PRIMARY KEY (director_id, genre_id), FOREIGN KEY (director_id) REFERENCES
directors(id), FOREIGN KEY (genre_id) REFERENCES genres(id) );

CREATE TABLE IF NOT EXISTS director_movie ( director_id INT, movie_id INT,
PRIMARY KEY (director_id, movie_id), FOREIGN KEY (director_id) REFERENCES
directors(id), FOREIGN KEY (movie_id) REFERENCES movies(movie_id) );

CREATE TABLE IF NOT EXISTS movies ( id INT PRIMARY KEY AUTO_INCREMENT, title
VARCHAR(255) NOT NULL, poster_path VARCHAR(255) NOT NULL, movie_id INT UNIQUE
NOT NULL, rating DECIMAL(3, 1) NOT NULL, trailer_url VARCHAR(255), resume TEXT,
sortie_date DATE, popularity_score DECIMAL(10, 2), number_of_ratings INT,
duration INT, director VARCHAR(255), actor VARCHAR(255), box_office DECIMAL(18,
2),INDEX(movie_id) );

CREATE TABLE IF NOT EXISTS user_movie_recommendations ( user_id INT, movie_id
INT, PRIMARY KEY (user_id, movie_id), FOREIGN KEY (user_id) REFERENCES
users(id), FOREIGN KEY (movie_id) REFERENCES movies(movie_id) );

# Faire l'importation des données dans la bdd :

node importMovie.js

# Lancer le serveur :

node server.js

# Commande python :

pip install mysql-connector-python

# Commande npm :

npm install express express-session mysql, npm install mysql2, npm install pm2
-g, npm install axios, npm install multer

# Note :

Pour l'instant l'algo de recommandation ne s'initalise que à chaque fois qu'on
lance le serveur donc avec node server.js Je sais que mon static n'est vraiment
pas très optimisées
