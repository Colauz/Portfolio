const express = require('express');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const { spawn } = require('child_process');
const { inscrireUtilisateur, gererConnexion } = require('./userController');
const connection = require('./db');
const app = express();
const port = 3000;


app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(session({
  secret: 'jesuispasheureux*',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: 'auto',
    sameSite: 'strict',
    maxAge: 1000 * 60 * 60 * 24 * 365 * 10
  }
}));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'public', 'profil', 'uploads'));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});



const upload = multer({ storage });

app.post('/api/upload-profil-picture', upload.single('photo_profil'), (req, res) => {
  const userId = req.session.userId;
  const photoPath = req.file.path;
  const fileName = req.file.filename; 

  const queryString = 'UPDATE users SET photo_profil = ? WHERE id = ?';
  connection.query(queryString, [photoPath, userId], (err, results) => {
    if (err) {
      console.error('Erreur lors de la mise à jour de la photo de profil:', err);
      return res.status(500).json({ error: 'Erreur serveur' });
    }

    res.json({ message: 'Photo de profil mise à jour avec succès', filename: req.file.filename });
  });
});


app.post('/verify-email', (req, res) => {
  const { value: email } = req.body;
  connection.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) {
      console.error('Erreur lors de la vérification de l\'email:', err);
      return res.status(500).json({ message: 'Erreur serveur lors de la vérification de l\'email' });
    }
    if (results.length > 0) {
      return res.json({ message: 'Cet email est déjà utilisé' });
    } else {
      return res.json({ message: '' });
    }
  });
});

app.post('/verify-pseudo', (req, res) => {
  const { value: pseudo } = req.body;
  connection.query('SELECT * FROM users WHERE pseudo = ?', [pseudo], (err, results) => {
    if (err) {
      console.error('Erreur lors de la vérification du pseudo:', err);
      return res.status(500).json({ message: 'Erreur serveur lors de la vérification du pseudo' });
    }
    if (results.length > 0) {
      return res.json({ message: 'Ce pseudo est déjà pris' });
    } else {
      return res.json({ message: '' });
    }
  });
});

app.get('/inscription', (req, res) => {
  res.sendFile(__dirname + '/public/inscription_connexion/inscription.html');
});

app.get('/pref', (req, res) => {
  res.sendFile(__dirname + '/public/inscription_connexion/serie_pref.html');
});

app.get('/plus', (req, res) => {
  res.sendFile(__dirname + '/public/plus/plus.html');
});

app.get('/plusreco', (req, res) => {
  res.sendFile(__dirname + '/public/plus/plusreco.html');
});

app.get('/js/plus', (req, res) => {
  res.sendFile(__dirname + '/public/plus/js/plus.js');
});

app.get('/bestnote', (req, res) => {
  res.sendFile(__dirname + '/public/film/best_note.html');
});

app.get('/bestscore', (req, res) => {
  res.sendFile(__dirname + '/public/film/best_score.html');
});

app.get('/bestview', (req, res) => {
  res.sendFile(__dirname + '/public/film/best_view.html');
});

app.get('/css/searchfilm', (req, res) => {
  res.sendFile(__dirname + '/public/film/css/search.css');
});

app.get('/film', (req, res) => {
  res.sendFile(__dirname + '/public/film/film.html');
});

app.get('/js/best', (req, res) => {
  res.sendFile(__dirname + '/public/film/js/best.js');
});

app.get('/profil', (req, res) => {
  res.sendFile(__dirname + '/public/profil/profil.html');
});

app.get('/css/profil', (req, res) => {
  res.sendFile(__dirname + '/public/profil/css/profil.css');
});

app.get('/js/profil', (req, res) => {
  res.sendFile(__dirname + '/public/profil/js/profil.js');
});

app.get('/connexion', (req, res) => {
  res.sendFile(__dirname + '/public/inscription_connexion/connexion.html');
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/accueil/accueil.html');
});

app.get('/css/styles_accueil', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/accueil/css/styles_accueil.css');
});

app.get('/css/style_register', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/inscription_connexion/css/styles_connexion_inscription.css');
});

app.get('/css/style_pref', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/inscription_connexion/css/pref.css');
});

app.get('/js/script_inscription', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/inscription_connexion/js/inscription.js');
});

app.get('/js/script_pref', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/inscription_connexion/js/pref.js');
});

app.get('/js/script_connexion', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/inscription_connexion/js/connexion.js');
});

app.get('/js/script_accueil', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/accueil/js/accueil.js');
});

app.get('/js/app', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/accueil/js/app.js');
});

app.get('/api.js', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/app.js');
});

app.get('/moviedetails', (req, res) => {
  res.sendFile(__dirname + '/public/movieDetails/movieDetails.html');
});

app.get('/jsdetail/movieDetails', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/movieDetails/js/movieDetails.js');
});

app.get('/cssdetail/movieDetails', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/movieDetails/css/movieDetails.css');
});

app.get('/css/stylessearch', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/recherche/css/styles.css');
});

app.get('/css/search', (req, res) => {
  res.type('text/css');
  res.sendFile(__dirname + '/public/recherche/css/search.css');
});

app.get('/recherche', (req, res) => {
  console.log("Route /recherche atteinte");
  res.sendFile(__dirname + '/public/recherche/recherche.html');
});

app.get('/js/recherche', (req, res) => {
  res.type('application/javascript');
  res.sendFile(__dirname + '/public/recherche/js/recherche.js');
});

app.post('/inscription', inscrireUtilisateur);

app.post('/connexion', async (req, res) => {
  await gererConnexion(req, res);
});

app.get('/api/utilisateur', (req, res) => {
  const userId = req.session.userId;

  const queryString = 'SELECT nom, prenom, pseudo, email, photo_profil, date_register FROM users WHERE id = ?';
  connection.query(queryString, [userId], (err, results) => {
    if (err) {
      console.error('Erreur lors de la recherche de l\'utilisateur:', err);
      return res.status(500).json({ error: 'Erreur serveur' });
    }

    if (results.length > 0) {
      const utilisateur = results[0];
      utilisateur.photo_profil = utilisateur.photo_profil || null;
      utilisateur.date_register = utilisateur.date_register.toLocaleDateString('fr-FR', { year: 'numeric', month: '2-digit', day: '2-digit' });
      res.json(utilisateur);
    } else {
      console.log('Utilisateur non trouvé pour l\'ID:', userId);
      res.status(404).json({ error: 'Utilisateur non trouvé' });
    }
  });
});

app.post('/api/utilisateur', (req, res) => {
  const userId = req.session.userId;
  const utilisateur = req.body;

  console.log(`Mise à jour de l'utilisateur avec l'ID ${userId}:`, utilisateur);

  const queryString = 'UPDATE users SET nom = ?, prenom = ?, pseudo = ?, email = ?, photo_profil = ? WHERE id = ?';
  connection.query(queryString, [utilisateur.nom, utilisateur.prenom, utilisateur.pseudo, utilisateur.email, utilisateur.photo_profil, userId], (err, results) => {
    if (err) {
      console.error('Erreur lors de la mise à jour de lutilisateur:', err);
      return res.status(500).json({ error: 'Erreur serveur' });
    }

    console.log(`Utilisateur avec l'ID ${userId} mis à jour avec succès`);
    res.json(utilisateur);
  });
});


app.post('/api/deconnexion', (req, res) => {
  console.log('Déconnexion demandée pour la session :', req.sessionID);
  req.session.destroy(err => {
    if (err) {
      console.log('Erreur lors de la destruction de la session :', err);
      return res.status(500).json({ message: 'Erreur lors de la déconnexion' });
    }
    res.clearCookie('connect.sid');
    console.log('Session détruite et cookie effacé');
    return res.json({ message: 'Déconnexion réussie' });
  });
});

app.get('/api/movies', async (req, res) => {
  try {
    const [movies, _] = await connection.promise().query(
      'SELECT title, poster_path, movie_id, rating FROM movies ORDER BY movie_id'
    );
    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des films:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération des films' });
  }
});

app.get('/api/top-box-office-movies', async (req, res) => {
  try {
    const [movies, _] = await connection.promise().query(
      'SELECT title, poster_path, movie_id, rating, box_office FROM movies ORDER BY box_office DESC LIMIT 100'
    );
    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des films:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération des films' });
  }
});

app.get('/api/top-rated-movies', async (req, res) => {
  try {
    const [movies, _] = await connection.promise().query(
      'SELECT title, poster_path, movie_id, rating FROM movies WHERE number_of_ratings > 1000 ORDER BY rating DESC LIMIT 100'
    );
    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des films:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération des films' });
  }
});

app.get('/api/top-popularity-movies', async (req, res) => {
  try {
    const [movies, _] = await connection.promise().query(
      'SELECT title, poster_path, movie_id, rating, popularity_score FROM movies ORDER BY popularity_score DESC LIMIT 100'
    );
    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des films:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération des films' });
  }
});



app.get('/api/movie/:movie_id', async (req, res) => {
  const { movie_id } = req.params;

  try {
    const query = `
    SELECT
    m.title,
    m.poster_path,
    m.movie_id,
    m.rating,
    m.trailer_url,
    m.resume,
    m.sortie_date,
    m.duration,
    m.director,
    m.actor,
    m.rating,
    GROUP_CONCAT(g.name ORDER BY g.name SEPARATOR ', ') AS genres
  FROM
    movies m
  LEFT JOIN
    movie_genres mg ON m.movie_id = mg.movie_id
  LEFT JOIN
    genres g ON mg.genre_id = g.id
  WHERE
    m.movie_id = ?
  GROUP BY
    m.movie_id`;
    const [movieDetails, _] = await connection.promise().query(query, [movie_id]);

    if (movieDetails.length > 0) {
      const movie = movieDetails[0];
      movie.genres = movie.genres ? movie.genres.split(', ') : [];
      res.json(movie);
    } else {
      res.status(404).json({ message: 'Film non trouvé' });
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des détails du film:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération des détails du film' });
  }
});

app.put('/api/user-movie-rating/:movie_id', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Vous devez être connecté pour noter un film' });
  }

  const { userRating } = req.body;
  const { movie_id } = req.params;

  if (!Number.isInteger(userRating) || userRating < -1 || userRating > 1) {
    console.log(`Erreur de validation : La note doit être un nombre entier entre -1 et 1 (valeur reçue : ${userRating})`);
    return res.status(400).json({ message: 'La note doit être un nombre entier entre -1 et 1' });
  }

  const query = `
    INSERT INTO user_movie_ratings (user_id, movie_id, rating)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE rating = ?;
  `;
  const values = [req.session.userId, movie_id, userRating, userRating];

  connection.query(query, values, async (error, result) => {
    console.log(`Resultat de la requête : ${JSON.stringify(result)}`);
    if (error) {
      console.error(`Erreur lors de la mise à jour de la note : ${error}`);
      return res.status(500).json({ message: 'Erreur lors de la mise à jour de la note' });
    }

    console.log(`ID du film : ${movie_id}`);
    console.log(`ID de l'utilisateur : ${req.session.userId}`);
    console.log(`Note mise à jour : utilisateur ${req.session.userId}, film ${movie_id}, note ${userRating}`);

    res.json({ message: 'Merci pour votre note !' });

    await executePythonScript(movie_id);
  });
});


app.get('/api/user-movie-ratings/:movie_id', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Vous devez être connecté pour récupérer votre note pour ce film.' });
  }

  const { movie_id } = req.params;
  const user_id = req.session.userId;

  const query = `
    SELECT rating
    FROM user_movie_ratings
    WHERE user_id = ? AND movie_id = ?;
  `;

  connection.query(query, [user_id, movie_id], async (error, results) => {
    if (error) {
      console.error(`Erreur lors de la récupération de la note : ${error}`);
      return res.status(500).json({ message: 'Erreur lors de la récupération de la note' });
    }

    if (results.length > 0) {
      const rating = results[0].rating;
      res.json({ rating });
    } else {
      res.status(404).json({ message: 'Note non trouvée' });
    }

    // Appeler la fonction executePythonScript ici
    await executePythonScript(movie_id);
  });
});

app.delete('/api/user-movie-rating_delete/:movie_id', async (req, res) => {
  if (!req.session.userId) {
      return res.status(401).json({ message: 'Vous devez être connecté pour supprimer votre note pour ce film.' });
  }

  const { movie_id } = req.params;
  const user_id = req.session.userId;

  const query = `
      DELETE FROM user_movie_ratings
      WHERE user_id = ? AND movie_id = ?;
  `;

  connection.query(query, [user_id, movie_id], async (error, result) => {
      if (error) {
          console.error(`Erreur lors de la suppression de la note : ${error}`);
          return res.status(500).json({ message: 'Erreur lors de la suppression de la note' });
      }

      if (result.affectedRows > 0) {
          res.json({ message: 'Note supprimée avec succès' });
      } else {
          res.status(404).json({ message: 'Note non trouvée ou déjà supprimée' });
      }

      // Appeler la fonction executePythonScript ici
      await executePythonScript(movie_id);
  });
});



app.get('/api/upcoming-trailers', async (req, res) => {
  console.log("Route /api/upcoming-trailers atteinte");
  try {
    const [results] = await connection.promise().query(`
      SELECT title, trailer_url, sortie_date, popularity_score
      FROM movies
      WHERE trailer_url IS NOT NULL AND DATE(sortie_date) > CURDATE()
      ORDER BY popularity_score DESC
      LIMIT 10;
    `);
    res.json(results);
  } catch (error) {
    console.error('Erreur lors de la récupération des bandes-annonces:', error);
    res.status(500).send('Erreur serveur lors de la récupération des bandes-annonces');
  }
});

async function searchMovies(query) {
  const sql = 'SELECT movie_id, title FROM movies WHERE title LIKE ? LIMIT 100;';
  const likeQuery = `%${query}%`;

  try {
    const [results, _] = await connection.promise().query(sql, [likeQuery]);
    return results;
  } catch (error) {
    console.error('Erreur lors de la recherche de films:', error);
    throw error;
  }
}

app.get('/api/search', async (req, res) => {
  const { query } = req.query;
  if (!query) {
    return res.json([]);
  }

  try {
    const results = await searchMovies(query);
    res.json(results);
  } catch (error) {
    console.error('Erreur lors de la recherche de films:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la recherche de films' });
  }
});

app.get('/api/movie-poster/:movie_id', async (req, res) => {
  const { movie_id } = req.params;

  try {
    const query = `
      SELECT poster_path
      FROM movies
      WHERE movie_id = ?
    `;
    const [result] = await connection.promise().query(query, [movie_id]);

    if (result.length > 0) {
      const movie = result[0];
      res.json({ poster_path: movie.poster_path });
    } else {
      res.status(404).json({ message: 'Film non trouvé' });
    }
  } catch (error) {
    console.error('Erreur lors de la récupération de l\'affiche du film:', error);
    res.status(500).json({ message: 'Erreur serveur lors de la récupération de l\'affiche du film' });
  }
});

app.get('/api/top-rated', async (req, res) => {
  try {
    const [topRated] = await connection.promise().query(`
        SELECT title, poster_path, movie_id, rating
        FROM movies
        WHERE rating IS NOT NULL AND number_of_ratings > 1000
        ORDER BY rating DESC, number_of_ratings DESC
        LIMIT 5;
    `);
    res.json(topRated);
  } catch (error) {
    console.error('Erreur lors de la récupération des films les mieux notés:', error);
    res.status(500).send('Erreur serveur lors de la récupération des films les mieux notés');
  }
});

app.get('/api/latest-releases', async (req, res) => {
  try {
    const [latestReleases] = await connection.promise().query(`
        SELECT title, poster_path, movie_id, rating
        FROM movies
        WHERE sortie_date <= CURDATE()
        ORDER BY sortie_date DESC, popularity_score DESC
        LIMIT 5;
    `);
    res.json(latestReleases);
  } catch (error) {
    console.error('Erreur lors de la récupération des dernières sorties:', error);
    res.status(500).send('Erreur serveur lors de la récupération des dernières sorties');
  }
});


async function executePythonScript(movieId) {
  return new Promise((resolve, reject) => {
    const pythonProcess = spawn('python', ['reco.py', movieId]);

    let pythonOutput = '';

    pythonProcess.stdout.on('data', (data) => {
      pythonOutput += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error(`Erreur du processus enfant : ${data}`);
    });

    pythonProcess.on('close', (code) => {
      if (code === 0) {
        resolve(pythonOutput);
      } else {
        reject(new Error(`Le script Python s'est terminé avec le code de sortie : ${code}`));
      }
    });
  });
}

app.post('/api/user-ratings', async (req, res) => {
  const userId = req.session.userId;
  console.log('id:', userId);

  try {
    const [ratings] = await connection.promise().query(`
      SELECT user_id, movie_id
      FROM user_movie_ratings
      WHERE user_id = ?;
    `, [userId]);

    if (ratings.length === 0) {
      res.status(404).send('Aucune note trouvée pour cet utilisateur');
      return;
    }

    console.log('ratings:', ratings);
    const movieIds = ratings.map(rating => rating.movie_id);
    const [movies] = await connection.promise().query(`
      SELECT id, title, poster_path, movie_id, rating, trailer_url, resume, sortie_date, popularity_score, number_of_ratings, duration, director, actor
      FROM movies
      WHERE movie_id IN (?);
    `, [movieIds]);

    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des informations sur les films:', error);
    res.status(500).send('Erreur serveur lors de la récupération des informations sur les films');
  }
});

app.get('/api/popular-movies-random', async (req, res) => {
  try {
    const [popularMoviesRandom] = await connection.promise().query(
      `SELECT title, poster_path, movie_id, rating
       FROM (
         SELECT title, poster_path, movie_id, rating
         FROM movies
         WHERE popularity_score IS NOT NULL
         ORDER BY popularity_score DESC, RAND()
         LIMIT 500
       ) subquery
       ORDER BY RAND()
       LIMIT 100;`
    );
    res.json(popularMoviesRandom);
  } catch (error) {
    console.error('Erreur lors de la récupération des films populaires aléatoires:', error);
    res.status(500).send('Erreur serveur lors de la récupération des films populaires aléatoires');
  }
});

app.post('/api/user-recommendations', async (req, res) => {
  const userId = req.session.userId;
  console.log('id:', userId);

  try {
    const [recommendations] = await connection.promise().query(`
      SELECT user_id, movie_id
      FROM user_movie_recommendations
      WHERE user_id = ?;
    `, [userId]);

    if (recommendations.length === 0) {
      res.status(404).send('Aucune recommandation trouvée pour cet utilisateur');
      return;
    }

    console.log('recommendations:', recommendations);
    const movieIds = recommendations.map(recommendation => recommendation.movie_id);
    const [movies] = await connection.promise().query(`
      SELECT id, title, poster_path, movie_id, rating, trailer_url, resume, sortie_date, popularity_score, number_of_ratings, duration, director, actor
      FROM movies
      WHERE movie_id IN (?);
    `, [movieIds]);

    res.json(movies);
  } catch (error) {
    console.error('Erreur lors de la récupération des informations sur les films:', error);
    res.status(500).send('Erreur serveur lors de la récupération des informations sur les films');
  }
});

app.listen(port, () => {
  console.log(`Le serveur est en cours d'exécution sur http://localhost:${port}`);
});