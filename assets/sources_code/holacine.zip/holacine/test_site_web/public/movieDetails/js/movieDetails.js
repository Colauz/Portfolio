function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

async function fetchUserRating(movieId) {
    const response = await fetch(`/api/user-movie-rating/${movieId}`);
    if (!response.ok) {
        console.error(`Erreur lors de la récupération de la note de l'utilisateur pour le film ${movieId}: Réponse du réseau non OK`);
        return null;
    }

    const rating = await response.json();
    return rating.rating || 0;
}

async function deleteUserRating(movieId) {
    try {
        const response = await fetch(`/api/user-movie-rating_delete/${movieId}`, {
            method: 'DELETE', 
        });

        if (!response.ok) throw new Error('Erreur lors de la suppression de la note');

        console.log('Note supprimée avec succès');
        updateUserRatingText(movieId); 
    } catch (error) {
        console.error('Erreur lors de la suppression de la note:', error);
    }
}


async function updateUserRatingText(movieId) {
    const lastRatingText = document.getElementById('last-rating-text');
    lastRatingText.innerHTML = '';

    try {
        const response = await fetch(`/api/user-movie-ratings/${movieId}`);
        if (!response.ok) throw new Error('Erreur lors de la récupération de la note');
        
        const { rating } = await response.json();
        let ratingText = '';
        let ratingHtml = '';

        switch (rating) {
            case 1:
                ratingText = "J'aime";
                break;
            case 0:
                ratingText = "Neutre";
                break;
            case -1:
                ratingText = "J'aime pas";
                break;
            default:
                ratingText = "Note non disponible";
                break;
        }

        if (rating !== undefined && rating !== null) {
            ratingHtml = `${ratingText} <button onclick="deleteUserRating(${movieId})">Supprimer la note</button>`;
        } else {
            ratingHtml = ratingText;
        }

        lastRatingText.innerHTML = ratingHtml;
    } catch (error) {
        console.error('Erreur lors de la mise à jour du texte de la note:', error);
        lastRatingText.textContent = "";
    }
}


function updateReactionButtons(userRating) {
    const likeButton = document.getElementById('like-button');
    const neutralButton = document.getElementById('neutral-button');
    const dislikeButton = document.getElementById('dislike-button');

    likeButton.classList.remove('selected');
    neutralButton.classList.remove('selected');
    dislikeButton.classList.remove('selected');

    switch (userRating) {
        case 1:
            likeButton.classList.add('selected');
            break;
        case 0:
            neutralButton.classList.add('selected');
            break;
        case -1:
            dislikeButton.classList.add('selected');
            break;
    }
}

async function loadMovieDetails() {
    const movieId = getQueryParam('movie_id');
    if (!movieId) {
        document.getElementById('movie-title').textContent = 'Film non spécifié';
        return;
    }

    try {
        const response = await fetch(`/api/movie/${movieId}`);
        if (!response.ok) throw new Error('Réponse du réseau non OK');

        const movie = await response.json();
        document.getElementById('movie-title').textContent = movie.title || 'Titre inconnu';

        document.getElementById('movie-title1').textContent = movie.title || 'Titre inconnu';

        const posterUrl = movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : '';
        document.getElementById('movie-poster').setAttribute('src', posterUrl);

        if (movie.genres && movie.genres.length > 0) {
            const genresText = movie.genres.join(', ');
            document.getElementById('movie-genres').textContent = `Genres: ${genresText}`;
        } else {
            document.getElementById('movie-genres').textContent = 'Genres: Genres non disponibles';
        }

        if (movie.trailer_url) {
            const embedUrl = movie.trailer_url.replace('watch?v=', 'embed/');
            const trailerFrame = `<iframe src="${embedUrl}" class="embed-responsive-item" allowfullscreen="" style="border:none; width:100%; height:315px;"></iframe>`;
            document.getElementById('movie-trailer').innerHTML = trailerFrame;
        } else {
            document.getElementById('movie-trailer').style.display = 'none';
        }

        if (movie.sortie_date) {

            const releaseDate = new Date(movie.sortie_date);

            const formattedDate = releaseDate.toLocaleDateString('fr-FR', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
            });

            document.getElementById('movie-release-date').textContent = `Date de sortie: ${formattedDate}`;
        } else {
            document.getElementById('movie-release-date').textContent = 'Date de sortie: Non disponible';
        }

        if (movie.resume) {
            document.getElementById('movie-resume').textContent = `Résumé: ${movie.resume}`;
        } else {
            document.getElementById('movie-resume').textContent = 'Résumé: Résumé non disponible';
        }

        if (movie.duration) {
            document.getElementById('movie-duration').textContent = `Durée: ${movie.duration} min`;
        } else {
            document.getElementById('movie-duration').textContent = 'Durée: Durée non disponible';
        }

        if (movie.director) {
            document.getElementById('movie-director').textContent = `Réalisateur(s): ${movie.director}`;
        } else {
            document.getElementById('movie-director').textContent = 'Réalisateur(s): Réalisateur(s) non disponible';
        }

        if (movie.actor) {
            document.getElementById('movie-actor').textContent = `Acteur(s): ${movie.actor}`;
        } else {
            document.getElementById('movie-actor').textContent = 'Acteur(s): Réalisateur(s) non disponible';
        }

        if (movie.rating !== null && movie.rating !== undefined) {
            const ratingContainer = document.getElementById('rating-stars');
            const ratingOutOfFive = movie.rating / 2;
            const fullStars = Math.floor(ratingOutOfFive);
            const halfStar = movie.rating % 2 !== 0 ? 1 : 0;
            const emptyStars = 5 - fullStars - halfStar;

            let starsHTML = '';
            for (let i = 0; i < fullStars; i++) {
                starsHTML += `<span class="star" data-rating="${ratingOutOfFive}">⭐<span class="tooltip">Note: ${ratingOutOfFive}/5</span></span>`;
            }
            if (halfStar) {
                starsHTML += `<span class="star" data-rating="${ratingOutOfFive}">☆<span class="tooltip">Note: ${ratingOutOfFive}/5</span></span>`;
            }
            for (let i = 0; i < emptyStars; i++) {
                starsHTML += `<span class="star" data-rating="${ratingOutOfFive}"><span class="tooltip">Note: ${ratingOutOfFive}/5</span></span>`;
            }

            ratingContainer.innerHTML = starsHTML;
        } else {
            document.getElementById('rating-stars').textContent = 'Note: Note non disponible';
        }

        const userRating = await fetchUserRating(movieId);
        
        if (userRating !== null) {
            updateReactionButtons(userRating);
        }
        

        updateUserRatingText(movieId);

    } catch (error) {
        console.error('Erreur lors de la récupération des détails du film:', error);
        document.getElementById('movie-title').textContent = 'Erreur lors du chargement des détails du film';
    }
}

window.onload = loadMovieDetails;

window.deconnexion = function () {
    fetch('/api/deconnexion', { method: 'POST' })
        .then(() => {
            console.log('Déconnexion réussie');
            localStorage.removeItem('estConnecte');
            localStorage.removeItem('userRating');
            sessionStorage.removeItem('estConnecte');
            window.location.href = '/';
        })
        .catch(error => console.error('Erreur lors de la déconnexion:', error));
};

document.addEventListener('DOMContentLoaded', function () {
    const estConnecte = localStorage.getItem('estConnecte');
    const divBoutons = document.querySelector('.auth-buttons');
    const commentFormContainer = document.getElementById('comment-form-container');
    const ratingContainer = document.getElementById('rating-stars');

    if (estConnecte === 'true') {
        divBoutons.innerHTML = `
            <button class="auth-button connexion-button" onclick="window.location.href='/profil'">Profil</button>
            <button class="auth-button deconnexion-button" id="boutonDeconnexion">Déconnexion</button>
        `;

        commentFormContainer.innerHTML = `
            <section id="comments">
                <form action="/submit_comment" method="post">
                    <label for="comment">Ajouter un commentaire :</label>
                    <textarea id="comment" name="comment" rows="4" required></textarea>
                    <button type="submit">Soumettre</button>
                </form>
            </section>
        `;

        const reactionButtonsHTML = `
            <div id="reaction-buttons" class="reaction-buttons">
                <button class="auth-button connexion-button" id="like-button">J'aime</button>
                <button class="auth-button connexion-button" id="neutral-button">Neutre</button>
                <button class="auth-button connexion-button" id="dislike-button">J'aime pas</button>
            </div>
        `;

        if (ratingContainer) {
            ratingContainer.insertAdjacentHTML('afterend', reactionButtonsHTML);
        }

        const likeButton = document.getElementById('like-button');
        const neutralButton = document.getElementById('neutral-button');
        const dislikeButton = document.getElementById('dislike-button');

        likeButton.addEventListener('click', handleReactionClick);
        neutralButton.addEventListener('click', handleReactionClick);
        dislikeButton.addEventListener('click', handleReactionClick);

    } else {
        divBoutons.innerHTML = `
            <button class="auth-button inscription-button" onclick="window.location.href='/inscription'">Inscription</button>
            <button class="auth-button connexion-button" onclick="window.location.href='/connexion'">Connexion</button>
        `;
    }

    const boutonDeconnexion = document.getElementById('boutonDeconnexion');
    if (boutonDeconnexion) {
        boutonDeconnexion.addEventListener('click', window.deconnexion);
    }

    const searchInput = document.getElementById('searchInput');
    const suggestionsContainer = document.getElementById('searchSuggestions');

    let mouseInsideSuggestions = false;

    searchInput.addEventListener('input', handleSearchInput);
    searchInput.addEventListener('focus', handleSearchFocus);

    suggestionsContainer.addEventListener('mouseenter', () => {
        mouseInsideSuggestions = true;
    });

    suggestionsContainer.addEventListener('mouseleave', () => {
        mouseInsideSuggestions = false;
    });

    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });
});

async function handleReactionClick(event) {
    const movieId = getQueryParam('movie_id').toString();
    console.log(`ID du film : ${movieId}`);

    let userRating;

    switch (event.target.id) {
      case 'like-button':
        userRating = 1;
        break;
      case 'neutral-button':
        userRating = 0;
        break;
      case 'dislike-button':
        userRating = -1;
        break;
      default:
        return;
    }

    try {
        const response = await fetch(`/api/user-movie-rating/${movieId}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              userRating
            })
          });

      if (!response.ok) throw new Error('Réponse du réseau non OK');

      const result = await response.json();
      console.log(result);

      // Appeler updateUserRatingText ici pour mettre à jour l'affichage de la note
      updateUserRatingText(movieId);

    } catch (error) {
      console.error('Erreur lors de l\'envoi de la note du film:', error);
    }
}



