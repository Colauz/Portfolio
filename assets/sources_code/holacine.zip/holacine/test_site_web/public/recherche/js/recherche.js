document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const query = urlParams.get('query');
  
    if (query) {
      fetch(`/api/search?query=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
          displaySearchResults(data);
        })
        .catch(error => console.error('Erreur lors de la récupération des résultats de recherche:', error));
    }
});
  
function displaySearchResults(movies) {
    const container = document.querySelector('.film-list');
    container.innerHTML = '';
  
    movies.forEach(movie => {
      const movieElement = document.createElement('a');
      movieElement.href = `/moviedetails?movie_id=${movie.movie_id}`;
      movieElement.classList.add('film-item');
  
      fetch(`/api/movie-poster/${movie.movie_id}`)
        .then(response => response.json())
        .then(data => {
          if (data.poster_path) {
            const image = document.createElement('img');
            image.src = `https://image.tmdb.org/t/p/w500${data.poster_path}`;
            image.alt = movie.title;
            image.loading = 'lazy';
            movieElement.appendChild(image);
          } else {
            console.log(`Poster path is missing for movie: ${movie.title}`);
          }
        })
        .catch(error => console.error('Erreur lors de la récupération de l\'affiche du film:', error));
  
      const title = document.createElement('p');
      title.textContent = movie.title;
  
      movieElement.appendChild(title);
  
      container.appendChild(movieElement);
    });
  
    if (movies.length === 0) {
      console.log("No movies found or API response is empty.");
    }
  }
  
  window.deconnexion = function () {
    fetch('/api/deconnexion', { method: 'POST' })
        .then(() => {
            console.log('Déconnexion réussie');
            localStorage.removeItem('estConnecte');
            sessionStorage.removeItem('estConnecte');
            window.location.href = '/';
        })
        .catch(error => console.error('Erreur lors de la déconnexion:', error));
};

document.addEventListener('DOMContentLoaded', function () {
    const estConnecte = localStorage.getItem('estConnecte');
    const divBoutons = document.querySelector('.auth-buttons');

    if (estConnecte === 'true') {
        divBoutons.innerHTML = `
            <button class="auth-button connexion-button" onclick="window.location.href='/profil'">Profil</button>
            <button class="auth-button deconnexion-button" id="boutonDeconnexion">Déconnexion</button>
        `;
    } else {
        divBoutons.innerHTML = `
            <button class="auth-button inscription-button" onclick="window.location.href='/inscription'">Inscription</button>
            <button class="auth-button connexion-button" onclick="window.location.href='/connexion'">Connexion</button>
        `;
    }

    const boutonDeconnexion = document.getElementById('boutonDeconnexion');
    if (boutonDeconnexion) {
        boutonDeconnexion.addEventListener('click', window.deconnexion);
    }

    const searchInput = document.getElementById('searchInput');
    const suggestionsContainer = document.getElementById('searchSuggestions');
    
    let mouseInsideSuggestions = false;

    searchInput.addEventListener('input', handleSearchInput);
    searchInput.addEventListener('focus', handleSearchFocus);

    suggestionsContainer.addEventListener('mouseenter', () => {
        mouseInsideSuggestions = true;
    });

    suggestionsContainer.addEventListener('mouseleave', () => {
        mouseInsideSuggestions = false;
    });

    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });
});

async function handleSearchInput() {
    const searchValue = this.value.trim();
    const suggestionsContainer = document.getElementById('searchSuggestions');

    if (searchValue.length > 0) {
        try {
            const response = await fetch(`/api/search?query=${encodeURIComponent(searchValue)}`);
            if (response.ok) {
                const movies = await response.json();
                updateSuggestions(movies, suggestionsContainer);
            } else {
                console.error('La requête a échoué :', response.statusText);
                suggestionsContainer.style.display = 'none';
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des suggestions de films:', error);
            suggestionsContainer.style.display = 'none';
        }
    } else {
        suggestionsContainer.style.display = 'none';
    }
}

function updateSuggestions(movies, suggestionsContainer) {
    suggestionsContainer.innerHTML = '';
    if (movies.length > 0) {
        movies.forEach(movie => {
            const suggestionElement = document.createElement('div');
            suggestionElement.classList.add('list-group-item');
            suggestionElement.textContent = movie.title;
            suggestionElement.onclick = () => {
                window.location.href = `/moviedetails?movie_id=${movie.movie_id}`;
            };
            suggestionsContainer.appendChild(suggestionElement);
        });
        suggestionsContainer.style.display = 'block';
    } else {
        suggestionsContainer.style.display = 'none';
    }
}

function handleSearchFocus() {
    const suggestionsContainer = document.getElementById('searchSuggestions');
    if (suggestionsContainer.innerHTML !== '') {
        suggestionsContainer.style.display = 'block';
    }
}

function displayPagination(currentPage, totalPages) {
    const paginationContainer = document.getElementById('pagination-container');
    paginationContainer.innerHTML = '';

    const firstPage = document.createElement('button');
    firstPage.innerText = '<< First';
    firstPage.onclick = () => fetchAndDisplayMovies(1);
    paginationContainer.appendChild(firstPage);

    for (let page = Math.max(1, currentPage - 2); page <= Math.min(currentPage + 2, totalPages); page++) {
        const pageButton = document.createElement('button');
        pageButton.innerText = page;
        pageButton.onclick = () => fetchAndDisplayMovies(page);
        if (page === currentPage) {
            pageButton.classList.add('active');
        }
        paginationContainer.appendChild(pageButton);
    }

    const lastPage = document.createElement('button');
    lastPage.innerText = 'Last >>';
    lastPage.onclick = () => fetchAndDisplayMovies(totalPages);
    paginationContainer.appendChild(lastPage);
}
