document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    
    fetch('/connexion', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: email, password: password }),
    })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            if (data.redirectTo) {
                localStorage.setItem('estConnecte', 'true');
                window.location.href = data.redirectTo;
            } else {
                alert(data.error || 'Erreur de connexion');
            }
        })
        .catch((error) => {
            console.error('Erreur:', error);
        });
});