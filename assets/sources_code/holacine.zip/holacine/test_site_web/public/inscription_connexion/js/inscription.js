function debounce(func, timeout = 500) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => { func.apply(this, args); }, timeout);
    };
}

function verifyField(fieldName, value) {
    fetch(`/verify-${fieldName}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ value }),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById(`${fieldName}-error`).textContent = data.message || '';
    })
    .catch(error => console.error('Error:', error));
}

document.getElementById('email').addEventListener('input', debounce((e) => {
    verifyField('email', e.target.value);
}));

document.getElementById('pseudo').addEventListener('input', debounce((e) => {
    verifyField('pseudo', e.target.value);
}));

document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = {
        nom: document.getElementById('nom').value,
        prenom: document.getElementById('prenom').value,
        email: document.getElementById('email').value,
        motdepasse: document.getElementById('motdepasse').value,
        pseudo: document.getElementById('pseudo').value
    };

    Promise.all([
        fetch(`/verify-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ value: formData.email }),
        }).then(response => response.json()),
        fetch(`/verify-pseudo`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ value: formData.pseudo }),
        }).then(response => response.json()),
    ])
    .then(([emailResponse, pseudoResponse]) => {
        let hasError = false;

        if (emailResponse.message) {
            document.getElementById('email-error').textContent = emailResponse.message;
            hasError = true;
        } else {
            document.getElementById('email-error').textContent = '';
        }

        if (pseudoResponse.message) {
            document.getElementById('pseudo-error').textContent = pseudoResponse.message;
            hasError = true;
        } else {
            document.getElementById('pseudo-error').textContent = '';
        }

        if (!hasError) {
            localStorage.setItem('formData', JSON.stringify(formData));
            window.location.href = "/pref";
        } 
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});