document.addEventListener('DOMContentLoaded', () => {
    displayPopularMoviesRandom();
});

let selectedMoviesCount = 0;

async function displayPopularMoviesRandom() {
    try {
      const response = await fetch('/api/popular-movies-random');
      const movies = await response.json();
      const moviesList = document.getElementById('popular-movies-random-list');
      moviesList.innerHTML = '';
      movies.forEach(movie => {
        const movieElement = createMovieElement(movie);
        moviesList.appendChild(movieElement);
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des films populaires aléatoires:', error);
    }
  }
  

function createMovieElement(movie) {
    const filmItem = document.createElement('div');
    filmItem.classList.add('film-item');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `film-${movie.movie_id}`;
    checkbox.classList.add('select-checkbox');

    const label = document.createElement('label');
    label.htmlFor = `film-${movie.movie_id}`;
    label.classList.add('select-label');

    const image = document.createElement('img');
    image.src = `https://image.tmdb.org/t/p/w500${movie.poster_path}`;
    image.alt = `Affiche du film: ${movie.title}`;

    const title = document.createElement('p');
    title.textContent = movie.title;
    title.classList.add('movie-title');

    const selectButton = document.createElement('button');
    selectButton.textContent = 'Sélectionner';
    selectButton.classList.add('select-button');
    selectButton.style.display = 'none';

    label.appendChild(image);
    label.appendChild(title);
    label.appendChild(selectButton);

    checkbox.addEventListener('change', function() {
      const movieTitle = label.querySelector('.movie-title');
      const btnSelect = label.querySelector('.select-button');
      updateValidateButton();
  
      if (checkbox.checked) {
        if (selectedMoviesCount < 10) {
          movieTitle.style.display = 'none';
          btnSelect.style.display = 'block';
          btnSelect.textContent = 'Sélectionné';
          selectedMoviesCount++;
        } else {
          checkbox.checked = false;
          alert("Vous avez déjà sélectionné 10 films. Veuillez en désélectionner certains avant d'en sélectionner d'autres.");
        }
      } else {
        movieTitle.style.display = 'block';
        btnSelect.style.display = 'none';
        btnSelect.textContent = 'Sélectionner';
        selectedMoviesCount--;
      }
    });

    filmItem.appendChild(checkbox);
    filmItem.appendChild(label);

    return filmItem;
}

function updateValidateButton() {
    const selectedFilms = document.querySelectorAll('.select-checkbox:checked');
    const validateButton = document.getElementById('validate-button');
  
    if (selectedFilms.length === 10) {
      validateButton.style.display = 'block';
    } else {
      validateButton.style.display = 'none';
    }
  }
  


  document.getElementById('validate-button').addEventListener('click', function(event) {
    event.preventDefault();
  
    const formData = JSON.parse(localStorage.getItem('formData'));
    const selectedCheckboxes = document.querySelectorAll('.select-checkbox:checked');
    const selectedMovieIds = Array.from(selectedCheckboxes).map(checkbox => checkbox.id.split('-')[1]);
  
    // Ajoutez les selectedMovieIds au formData
    formData.selectedMovieIds = selectedMovieIds;
  
    localStorage.removeItem('formData');
  
    fetch('/inscription', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
    .then(response => response.json())
    .then(data => {
      if (data.message && data.message === 'Inscription réussie') {
        window.location.href = "/";
      }
    })
    .catch((error) => {
      console.error('Error:', error);
    });
  });
  
