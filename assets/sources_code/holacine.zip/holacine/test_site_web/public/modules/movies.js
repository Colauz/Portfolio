const moviesDiv = document.getElementById("movies");
const paginationDiv = document.getElementById("pagination");

const moviesPerPage = 20;
let currentPage = 1;
const imageBaseUrl = 'https://image.tmdb.org/t/p/w1280';

async function getPopularMovies(page) {
  try {
    const response = await fetch(`/api/movies?page=${page}`);
    if (!response.ok) throw new Error('Problème lors de la récupération des films');
    const movies = await response.json();
    return movies;
  } catch (error) {
    console.error('Erreur lors de la récupération des films:', error);
    return [];
  }
}

export async function renderMovies() {
  await renderPage(currentPage);
  renderPagination();
}

async function renderPage(page) {
  const movies = await getPopularMovies(page);
  moviesDiv.innerHTML = movies?.map(movie => renderSingleMovie(movie)).join("");
}

function renderSingleMovie(movie) {
    const imagePath = movie.poster_path ? `${imageBaseUrl}${movie.poster_path}` : '';
    return (
      `
      <div class="col-4 col-lg-3 col-xl-2 p-1">
          <a href="/moviedetails?movie_id=${movie.movie_id}">
              <img src="${imagePath}" class="img-fluid hover-effect" alt="${movie.title}">
          </a>
      </div>
      `
    );
  }
  
function renderPagination() {
  const totalPages = Math.ceil(500 / moviesPerPage);
  const maxVisiblePages = 5;
  const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

  paginationDiv.innerHTML = `
    <nav aria-label="Page navigation">
        <ul class="pagination">
            ${renderPaginationItem("First", currentPage > 1, 1)}
            ${renderPaginationItem("Previous", currentPage > 1, currentPage - 1)}
            ${Array.from({ length: endPage - startPage + 1 }, (_, index) =>
                renderPaginationItem(startPage + index, true, startPage + index, currentPage === startPage + index)
            ).join("")}
            ${renderPaginationItem("Next", currentPage < totalPages, currentPage + 1)}
            ${renderPaginationItem("Last", currentPage < totalPages, totalPages)}
        </ul>
    </nav>
  `;
}

function renderPaginationItem(label, isEnabled, pageNumber, isActive = false) {
  return `
      <li class="page-item ${isActive ? "active" : ""}" ${isEnabled ? `onclick="changePage(${pageNumber})"` : ""}>
          <a class="page-link" href="#" ${isEnabled ? `data-page="${pageNumber}"` : ""}>${label}</a>
      </li>
  `;
}

window.changePage = function (newPage) {
  currentPage = newPage;
  renderPage(currentPage);
  renderPagination();
};
