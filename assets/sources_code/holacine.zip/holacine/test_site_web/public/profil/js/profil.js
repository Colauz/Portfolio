document.addEventListener('DOMContentLoaded', () => {
  fetch('/api/utilisateur')
    .then(response => {
      if (!response.ok) {
        throw new Error(`Problème avec la réponse de l'API: ${response.statusText}`);
      }
      return response.json();
    })
    .then(utilisateur => {
      console.log(utilisateur);
      console.log(utilisateur.id);
      document.getElementById('pseudoUtilisateur').textContent = utilisateur.pseudo;
      document.getElementById('date').textContent = utilisateur.date_register;
      displayUserRatedMovies(utilisateur.id);
      displayUserRecoMovies(utilisateur.id);

      // Stocker la photo de profil dans l'objet utilisateur
      utilisateur.photo_profil = utilisateur.photo_profil;
      window.utilisateur = utilisateur;

      // Afficher la photo de profil
      const profilePic = document.querySelector('.profile-pic');
      profilePic.src = utilisateur.photo_profil;
    })
    .catch(error => console.error('Erreur:', error));
});


async function displayUserRatedMovies(userId) {
  try {
    const response = await fetch('/api/user-ratings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ userId })
    });
    const movies = await response.json();
    const moviesList = document.getElementById('user-rated-movies-list');
    moviesList.innerHTML = '';

    const limitedMovies = movies.slice(0, 4);
    limitedMovies.forEach(movie => {
      const movieElement = createMovieElement(movie);
      moviesList.appendChild(movieElement);
    });

    if (movies.length > 4) {
      const voirPlusElement = createVoirPlusElement();
      moviesList.appendChild(voirPlusElement);
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des films notés par l\'utilisateur:', error);
  }
}

async function displayUserRecoMovies(userId) {
  try {
    const response = await fetch('/api/user-recommendations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ userId })
    });
    const movies = await response.json();
    const moviesList = document.getElementById('user-rated-reco-list');
    moviesList.innerHTML = '';

    const limitedMovies = movies.slice(0, 4);
    limitedMovies.forEach(movie => {
      const movieElement = createMovieElement(movie);
      moviesList.appendChild(movieElement);
    });

    if (movies.length > 4) {
      const voirPlusElement = createVoirPlusElement('/plusreco');
      moviesList.appendChild(voirPlusElement);
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des films notés par l\'utilisateur:', error);
  }
}

function createMovieElement(movie) {
  const anchor = document.createElement('a');
  anchor.href = `/moviedetails?movie_id=${movie.movie_id}`;
  anchor.classList.add('movie-item');

  const image = document.createElement('img');
  image.src = `https://image.tmdb.org/t/p/w500${movie.poster_path}`;
  image.alt = `Affiche du film: ${movie.title}`;

  const title = document.createElement('p');
  title.textContent = movie.title;

  anchor.appendChild(image);
  anchor.appendChild(title);

  return anchor;
}

function createVoirPlusElement(url = '/plus') {
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.classList.add('movie-item', 'voir-plus');

  const image = document.createElement('div');
  image.classList.add('voir-plus-poster');

  const text = document.createElement('p');
  text.textContent = 'Voir plus';

  image.appendChild(text);
  anchor.appendChild(image);

  return anchor;
}

const form = document.getElementById('upload-profil-picture-form');
const input = document.getElementById('photo_profil');

input.addEventListener('change', async (e) => {
  e.preventDefault();

  const formData = new FormData(form);

  try {
    const response = await fetch('/api/upload-profil-picture', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Problème avec la réponse de l'API: ${response.statusText}`);
    }

    const data = await response.json();
    console.log(data.message);

    const profilePic = document.querySelector('.profile-pic');
    profilePic.src = `/profil/uploads/${data.filename}`;

    utilisateur.photo_profil = `/profil/uploads/${data.filename}`;
    await updateUser(utilisateur);
  } catch (error) {
    console.error('Erreur:', error);
  }
});

async function updateUser(utilisateur) {
  try {
    const response = await fetch('/api/utilisateur', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(utilisateur)
    });

    if (!response.ok) {
      throw new Error(`Problème avec la réponse de l'API: ${response.statusText}`);
    }

    const updatedUtilisateur = await response.json();
    console.log(updatedUtilisateur.message);
    // Mettre à jour l'objet utilisateur dans la session ou le cache
    updatedUtilisateur.photo_profil = `/profil/uploads/${updatedUtilisateur.photo_profil}`;
    window.utilisateur = updatedUtilisateur;
  } catch (error) {
    console.error('Erreur:', error);
  }
}


