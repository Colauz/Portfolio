document.addEventListener('DOMContentLoaded', async () => {
    await displayMovies();
    await displayBestNote();
    await displayBoxOffice();
    await displayBestScore();
});
  
async function displayMovies() {
    try {
        const response = await fetch('/api/movies');
        const movies = await response.json();
        const moviesList = document.getElementById('movies');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des films les mieux notés:', error);
    }
}

async function displayBoxOffice() {
    try {
        const response = await fetch('/api/top-box-office-movies');
        const movies = await response.json();
        const moviesList = document.getElementById('box_office');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des films les mieux notés:', error);
    }
}

async function displayBestNote() {
    try {
        const response = await fetch('/api/top-rated-movies');
        const movies = await response.json();
        const moviesList = document.getElementById('note');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des films les mieux notés:', error);
    }
}

async function displayBestScore() {
    try {
        const response = await fetch('/api/top-popularity-movies');
        const movies = await response.json();
        const moviesList = document.getElementById('score');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des films les mieux notés:', error);
    }
}

  function createMovieElement(movie) {
    const anchor = document.createElement('a');
    anchor.href = `/moviedetails?movie_id=${movie.movie_id}`;
    anchor.classList.add('movie-item');
  
    const image = document.createElement('img');
    image.src = `https://image.tmdb.org/t/p/w500${movie.poster_path}`;
    image.alt = `Affiche du film: ${movie.title}`;
  
    const title = document.createElement('p');
    title.textContent = movie.title;
  
    anchor.appendChild(image);
    anchor.appendChild(title);
  
    return anchor;
  }
  