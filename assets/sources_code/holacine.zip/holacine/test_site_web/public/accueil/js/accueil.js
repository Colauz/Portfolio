document.addEventListener('DOMContentLoaded', function () {
    const estConnecte = localStorage.getItem('estConnecte');
    const divBoutons = document.querySelector('.auth-buttons');

    if (estConnecte === 'true') {
        divBoutons.innerHTML = `
            <button class="auth-button connexion-button" onclick="window.location.href='/profil'">Profil</button>
            <button class="auth-button deconnexion-button" id="boutonDeconnexion">Déconnexion</button>
        `;
    } else {
        divBoutons.innerHTML = `
            <button class="auth-button inscription-button" onclick="window.location.href='/inscription'">Inscription</button>
            <button class="auth-button connexion-button" onclick="window.location.href='/connexion'">Connexion</button>
        `;
    }

    const boutonDeconnexion = document.getElementById('boutonDeconnexion');
    if (boutonDeconnexion) {
        boutonDeconnexion.addEventListener('click', window.deconnexion);
    }

    const searchInput = document.getElementById('searchInput');
    const suggestionsContainer = document.getElementById('searchSuggestions');

    let mouseInsideSuggestions = false;

    searchInput.addEventListener('input', handleSearchInput);
    searchInput.addEventListener('focus', handleSearchFocus);

    suggestionsContainer.addEventListener('mouseenter', () => {
        mouseInsideSuggestions = true;
    });

    suggestionsContainer.addEventListener('mouseleave', () => {
        mouseInsideSuggestions = false;
    });

    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });
});

async function handleSearchInput() {
    const searchValue = this.value.trim();
    const suggestionsContainer = document.getElementById('searchSuggestions');

    if (searchValue.length > 0) {
        try {
            const response = await fetch(`/api/search?query=${encodeURIComponent(searchValue)}`);
            if (response.ok) {
                const movies = await response.json();
                updateSuggestions(movies, suggestionsContainer);
            } else {
                console.error('La requête a échoué :', response.statusText);
                suggestionsContainer.style.display = 'none';
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des suggestions de films:', error);
            suggestionsContainer.style.display = 'none';
        }
    } else {
        suggestionsContainer.style.display = 'none';
    }
}

function updateSuggestions(movies, suggestionsContainer) {
    suggestionsContainer.innerHTML = '';
    if (movies.length > 0) {
        movies.forEach(movie => {
            const suggestionElement = document.createElement('div');
            suggestionElement.classList.add('list-group-item');
            suggestionElement.textContent = movie.title;
            suggestionElement.onclick = () => {
                window.location.href = `/moviedetails?movie_id=${movie.movie_id}`;
            };
            suggestionsContainer.appendChild(suggestionElement);
        });
        suggestionsContainer.style.display = 'block';
    } else {
        suggestionsContainer.style.display = 'none';
    }
}

function handleSearchFocus() {
    const suggestionsContainer = document.getElementById('searchSuggestions');
    if (suggestionsContainer.innerHTML !== '') {
        suggestionsContainer.style.display = 'block';
    }
}

window.deconnexion = function () {
    fetch('/api/deconnexion', { method: 'POST' })
        .then(() => {
            console.log('Déconnexion réussie');
            localStorage.removeItem('estConnecte');
            sessionStorage.removeItem('estConnecte');
            window.location.href = '/';
        })
        .catch(error => console.error('Erreur lors de la déconnexion:', error));
};

let players = [];

function createPlayer(videoId, index) {
    const player = new YT.Player(`player-${index}`, {
        height: '360',
        width: '640',
        videoId: videoId,
        playerVars: {
            'autoplay': 0,
            'controls': 1,
            'showinfo': 0,
            'rel': 0
        },
        events: {
            'onReady': onPlayerReady
        }
    });
    players.push(player);
}


function onPlayerReady(event) {
    event.target.stopVideo();
}

function pauseAllVideos() {
    players.forEach(player => {
        if (player && player.getPlayerState) {
            const state = player.getPlayerState();
            if (state === 1) { // 1 représente l'état "en lecture" de YouTube Player API
                player.pauseVideo();
            }
        }
    });
}





document.addEventListener('DOMContentLoaded', () => {
    fetchUpcomingTrailers();

    document.querySelector('.trailer-nav.prev').addEventListener('click', () => {
        pauseAllVideos(); // Appel de pauseAllVideos avant de naviguer
        navigateTrailer('prev');
    });

    document.querySelector('.trailer-nav.next').addEventListener('click', () => {
        pauseAllVideos(); // Appel de pauseAllVideos avant de naviguer
        navigateTrailer('next');
    });
});

let currentTrailerIndex = 0;

async function fetchUpcomingTrailers() {
    try {
        console.log("Fetching trailers...");
        const response = await fetch('/api/upcoming-trailers');
        const trailers = await response.json();
        console.log("Trailers received:", trailers);
        displayTrailers(trailers);
    } catch (error) {
        console.error('Erreur lors de la récupération des bandes-annonces:', error);
    }
}

function displayTrailers(trailers) {
    const trailerContainer = document.querySelector('.trailer-content');
    trailerContainer.innerHTML = '';
    trailers.forEach((trailer, index) => {
        const trailerElement = document.createElement('div');
        trailerElement.className = 'trailer-item';
        trailerElement.style.display = index === 0 ? 'block' : 'none';

        // Formatez la date de sortie
        const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = new Date(trailer.sortie_date).toLocaleDateString('fr-FR', dateOptions);

        // Créez un nouvel élément div pour chaque vidéo
        const playerDiv = document.createElement('div');
        playerDiv.id = `player-${index}`;

        trailerElement.appendChild(playerDiv);

        const trailerInfo = document.createElement('div');
        trailerInfo.className = 'trailer-info';
        trailerInfo.innerHTML = `
            <h3>${trailer.title}</h3>
            <p>Date de sortie: ${formattedDate}</p>
        `;
        trailerElement.appendChild(trailerInfo);

        trailerContainer.appendChild(trailerElement);

        // Créez un nouvel objet YT.Player pour chaque vidéo
        createPlayer(trailer.trailer_url.split('v=')[1], index);
    });
}



function navigateTrailer(direction) {
    const trailers = document.querySelectorAll('.trailer-item');

    trailers[currentTrailerIndex].style.display = 'none';

    if (direction === 'next') {
        currentTrailerIndex = (currentTrailerIndex + 1) % trailers.length;
    } else {
        currentTrailerIndex = (currentTrailerIndex - 1 + trailers.length) % trailers.length;
    }

    trailers[currentTrailerIndex].style.display = 'block';

    if (players[currentTrailerIndex] && players[currentTrailerIndex].getPlayerState) {
        players[currentTrailerIndex].playVideo();
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    fetchUpcomingTrailers();
    await displayTopRatedMovies();
    await displayLatestReleases();
});

async function displayTopRatedMovies() {
    try {
        const response = await fetch('/api/top-rated');
        const movies = await response.json();
        const moviesList = document.getElementById('top-rated-list');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des films les mieux notés:', error);
    }
}

async function displayLatestReleases() {
    try {
        const response = await fetch('/api/latest-releases');
        const movies = await response.json();
        const moviesList = document.getElementById('latest-releases-list');
        moviesList.innerHTML = ''; 
        movies.forEach(movie => {
            const movieElement = createMovieElement(movie);
            moviesList.appendChild(movieElement);
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des dernières sorties:', error);
    }
}

function createMovieElement(movie) {
    const anchor = document.createElement('a');
    anchor.href = `/moviedetails?movie_id=${movie.movie_id}`; 
    anchor.classList.add('movie-item');

    const image = document.createElement('img');
    image.src = `https://image.tmdb.org/t/p/w500${movie.poster_path}`;
    image.alt = `Affiche du film: ${movie.title}`;

    const title = document.createElement('p');
    title.textContent = movie.title;

    anchor.appendChild(image);
    anchor.appendChild(title);

    return anchor;
}
