import { renderMovies } from '../modules/movies.js';

function App() {
    renderMovies();
}

App();
