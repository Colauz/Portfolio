import mysql.connector
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

def connect_to_database():
    try:
        cnx = mysql.connector.connect(user='root', password='root', host='localhost', database='holacine')
        return cnx
    except mysql.connector.Error as err:
        print(f"Error: {err}")

def fetch_table_data(table_name, cursor):
    query = f"SELECT * FROM {table_name}"
    cursor.execute(query)
    return cursor.fetchall()

def calculate_cosine_similarity(movie_id_to_features):
    movie_features = np.array([features for features in movie_id_to_features.values()])
    return cosine_similarity(movie_features)

def generate_recommendations(user_id, user_rated_movies, movie_id_to_title, movie_similarity, rated_movies):
    recommendations = []
    for movie_id, rating in user_rated_movies.items():
        if rating == 1:
            if movie_id < len(movie_similarity):
                similarities = movie_similarity[movie_id]
                for similar_movie_id, similarity in enumerate(similarities):
                    if similarity > 0 and similar_movie_id not in rated_movies:
                        movie_title = movie_id_to_title[similar_movie_id]
                        recommendations.append((similar_movie_id, movie_title, similarity))
            else:
                print(f"L'ID de film {movie_id} n'est pas valide ou dépasse la taille du tableau movie_similarity.")
    recommendations = sorted(recommendations, key=lambda x: x[2], reverse=True)[:100]  # Limiter à 100 recommandations
    return recommendations

def is_movie_id_valid(movie_id, cursor):
    cursor.execute("SELECT EXISTS(SELECT 1 FROM movies WHERE movie_id=%s)", (movie_id,))
    return cursor.fetchone()[0] == 1

def main():
    try:
        cnx = connect_to_database()
        if not cnx:
            return

        cursor = cnx.cursor()

        cursor.execute("TRUNCATE TABLE user_movie_recommendations")
        cnx.commit()

        user_movie_ratings = fetch_table_data('user_movie_ratings', cursor)
        user_id_to_rated_movies = {}
        rated_movies = set()
        for rating in user_movie_ratings:
            user_id, movie_id, _ = rating
            if user_id not in user_id_to_rated_movies:
                user_id_to_rated_movies[user_id] = {}
            user_id_to_rated_movies[user_id][movie_id] = _
            rated_movies.add(movie_id)

        print("user_id_to_rated_movies:", user_id_to_rated_movies)

        tables = ['movie_genres', 'movie_actor', 'director_movie']
        movie_features = {}
        for table in tables:
            table_data = fetch_table_data(table, cursor)
            for row in table_data:
                movie_id = row[0]
                if movie_id not in movie_features:
                    movie_features[movie_id] = set()
                movie_features[movie_id].add(row[1])

        print("movie_features:", movie_features)

        movie_id_to_index = {movie_id: index for index, movie_id in enumerate(sorted(movie_features.keys()))}
        movie_index_to_id = {index: movie_id for movie_id, index in movie_id_to_index.items()}
        movie_id_to_vector = {movie_id: [0 if feature not in features else 1 for feature in sorted(set().union(*movie_features.values()))] for movie_id, features in movie_features.items()}
        movie_similarity = calculate_cosine_similarity({index: vector for index, vector in enumerate(movie_id_to_vector.values())})

        print("movie_similarity:", movie_similarity)

        user_id_to_recommendations = {}
        for user_id, rated_movies in user_id_to_rated_movies.items():
            recommendations = generate_recommendations(user_id, rated_movies, movie_index_to_id, movie_similarity, rated_movies)
            user_id_to_recommendations[user_id] = recommendations

            print(f"Recommendations for user {user_id}:")
            for movie_id, movie_title, similarity in recommendations:
                print(f"\tMovie ID: {movie_id}, Title: {movie_title}, Similarity: {similarity}")

        for user_id, recommendations in user_id_to_recommendations.items():
            for movie_id, _, _ in recommendations:
                if is_movie_id_valid(movie_id, cursor):
                    cursor.execute("INSERT IGNORE INTO user_movie_recommendations (user_id, movie_id) VALUES (%s, %s)", (user_id, movie_id))

        cnx.commit()

    finally:
        if cnx.is_connected():
            cursor.close()
            cnx.close()

if __name__ == "__main__":
    main()