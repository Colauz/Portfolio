Si on veut push :

git init -A

git commit -m "message"

git push

Si on veut pull :

juste git pull
